# combines fastq forwards and backwards reads into a single file by interleaving
# fastq1_name: Path to the fq1 file as String
# fastq2_name: Path to the fq2 file as String
# output_name: Desired name of the output fastq file
function combine_fastq_files(fastq1_name, fastq2_name, output_name)
    fastq_1 = open(fastq1_name, "r")
    fastq_2 = open(fastq2_name, "r")
    output = open(output_name, "w+")

    while !eof(fastq_1)
        output_buffer = []
        write(output, "$(readline(fastq_1)) \n")
        write(output, "$(readline(fastq_1)) \n")
        write(output, "$(readline(fastq_1)) \n")
        write(output, "$(readline(fastq_1)) \n")
        write(output, "$(readline(fastq_2)) \n")
        write(output, "$(readline(fastq_2)) \n")
        write(output, "$(readline(fastq_2)) \n")
        write(output, "$(readline(fastq_2)) \n")
    end

    close(fastq_1)
    close(fastq_2)
    close(output)
end

# Get a list of base files given the clean reads from directory
# input_dir: Directory to look for clean reads in as String
function get_base_filenames_from_clean_reads(input_dir)
    base_files = []
    for filename in readdir(input_dir)
        if endswith(filename, "clean_1.fastq")
            basefile = SubString(filename, 1, length(filename) - 14)
            push!(base_files, basefile)
        end
    end
    return base_files
end

# Sanitise directory name to ensure it has a trailing /
# directory: Path to directory as string
function sanitise_directory_string(directory)
    #if input does not end with trailing /
    if !endswith(directory, "/")
       directory = string(directory, "/")
    end
    return directory
end

# Generate PBS file headers
# job_name: Job name
# threads: Number of threads to use
# walltime: Walltime (in hours)
# mem: Memory (in GBs)
# email: Email to send job status to
# working_dir: Working directory to start job in
function get_pbs_template_headers(job_name, threads, walltime, mem, email, working_dir)
    pbs_header = """#!/bin/bash
#PBS -N $(job_name)
#PBS -l nodes=1:ppn=$threads
#PBS -l walltime=$walltime:00:00
#PBS -l mem=$(mem)GB
#PBS -m ae
#PBS -M $email

cd $working_dir
"""
    return pbs_header
end
