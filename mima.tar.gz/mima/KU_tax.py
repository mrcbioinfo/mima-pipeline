import argparse
import os
import pandas as pd


parser = argparse.ArgumentParser()
parser.add_argument('--metadata',
                    required=True,
                    #type=argparse.FileType('r', encoding='UTF-8'),
                    #nargs='+',
                    help='path to metadata file in .csv format')
parser.add_argument('--threads', '-t',
                    type=int,
                    default=8,
                    help='number of threads')
parser.add_argument('--input_dir',
                    required=True,
                    help='file path to input directory of clean sequences (post QC)')


args = parser.parse_args()

metadata=args.metadata
df = pd.read_csv(metadata)
file_metadata = df.to_dict('records')


input_dir=args.input_dir
#if input does not end with
if not input_dir.endswith("/"):
    input_dir += '/'


out_dir = "kraken"
KU_path = os.path.join(input_dir, out_dir)
os.mkdir(KU_path)


def get_KU_command(input_dir, base_filename, threads, outdir):
    KU_command=f"""krakenuniq --db /srv/scratch/mrcbio/db/KrakenUniqDB --threads {threads} --unclassified-out {outdir}/{base_filename}.unclassified.fq --classified-out  {outdir}/{base_filename}.classified.fq --output {outdir}/{base_filename}.output --preload --paired --report-file {outdir}/{base_filename}.report {input_dir}{base_filename}_clean_1.fastq {input_dir}{base_filename}_clean_2.fastq
"""
    return KU_command

with open(f'{KU_path}/kraken_commands.tsv', "w+") as output_file:
    for ID in file_metadata:
        filecommands = [get_KU_command(input_dir, ID["Sample_ID"], args.threads, KU_path)]
        print(filecommands)
        output_file.write('\t'.join(str(x) for x in filecommands))

