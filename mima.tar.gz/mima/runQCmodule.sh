abspath=/srv/scratch/$USER/examples
outdir=output

rm -fr ${abspath}/${outdir}/QC_module

cmd="python3 qc_module.py -i ${abspath}/15_PRJEB13835/raw_data/ -o ${abspath}/${outdir} -m ${abspath}/15_PRJEB13835/metadata/manifest.csv -e x.chua@unsw.edu.au --walltime 10"

echo ""
echo $cmd
exec $cmd
