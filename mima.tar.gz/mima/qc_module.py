"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Quality Check module

This is part of the MRC Metagenomics pipeline. This is the quality checking module that generates
PBS scripts for processing multiple samples in a study. The script contains commands for the three
steps:

1. Dereplication of reads using clumpify from BBTools
2. Quality checking using Fastp
3. Decontamination by removing reads that map to Human genome using minimap2

The pipeline is suitable for metagenomic analyses where samples are processed by
shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import os
import pandas as pd
import logging
from sys import argv


# %% Helper functions

# TODO: move functions

def is_gzipped(filename):
    """
    Check if input file is gzipped

    Parameters
    ----------
        filename: str
            input filepath

    Returns:
        boolean
    """

    if filename.endswith(".gz"):
        return True
    else:
        return False


def get_pbs_template_headers(sample_ID, threads, walltime, mem, email, output_dir):
    """
    Function for PBS header template

    Parameters
    ----------
        sample_ID : str
            Name used for naming the PBS job
        threads : int
            Number of threads for job
        walltime : int
            Number of hours predicted for job
        mem : int
            Memory (GB) required for job
        email : str
            User email address
        output_dir str: 
            Path to output where results will be saved

    Returns:
        str: PBS header settings
    """

#    pbs_header = f"""#!/bin/bash
#PBS -N {sample_ID}_qc_module
#PBS -l nodes=1:ppn={threads}
#PBS -l walltime={walltime}:00:00
#PBS -l mem={mem}GB
#PBS -m ae
#PBS -j oe
#PBS -M {email}
#cd {output_dir}
#conda activate mima
#"""
    pbs_header = f"""#!/bin/bash
#PBS -N {sample_ID}_qc_module
#PBS -l ncpus={threads}
#PBS -l walltime={walltime}:00:00
#PBS -l mem={mem}GB
#PBS -m ae
#PBS -j oe

source ~/myconda

cd {output_dir}
conda activate mima
"""
    return pbs_header


def get_unzip_base_file_command(input_dir, filename_R1, filename_R2):
    """
    Function for files to be unzipped

    Parameters
    ----------
    input_dir : str
        Directory path where input files are stored and will be unzipped
    filename_R1 : str
        Name of foward FastQ file
    filename_R2 : str
        Name of reverse FastQ file

    Returns
    -------
        Function for unzipping file

    """
    unzip_function = f"""    
gunzip {input_dir}{filename_R1}
gunzip {input_dir}{filename_R2}
"""
    return unzip_function


def get_common_qc_command(input_dir, filename_R1, filename_R2, base_filename, 
                          subs, threads, #dupedist, 
                          ref, clean_dir, qc_dir, raw_dir):
    """

    Function to return the command strings for QC steps: 
        dereplication with clumpify
        fastp checking
        removing host DNA reads using minimap2

    Parameters
    ----------
    input_dir : str
        Directory path where input files are stored
    base_filename : str
        Base filename
    subs : int
        Subs for clumplify.sh from BBTools - (s) Maximum substitutions allowed between duplicates
    threads : int
        Number of threads to use for 
    dupedist : int
        Deduplication setting used in clumpify.sh from BBTools
    ref : str
        Path to reference sequence for host genome for decontamination
    clean_dir : str
        Directory path to save output after final decontamination step
    qc_dir : str
        Directory path to save output after QC step with Fastp
    raw_dir : str
        Directory path to save the raw data 

    Returns
    -------
        str: QC commands to put into PBS script
    """
    
    ## TODO: use gzipped version of input and output
    ## TODO: should not move the raw data

#clumpify.sh in1={input_dir}{base_filename}_R1_001.fastq in2={input_dir}{base_filename}_R2_001.fastq out={base_filename}_clumpify_1.fastq out2={base_filename}_clumpify_2.fastq dedupe subs={subs} threads={threads} dupedist={dupedist}
    common_qc_command = f"""unset _JAVA_OPTIONS

repair.sh in1={input_dir}{filename_R1} in2={input_dir}{filename_R2} out={base_filename}_repaired1.fq.gz out2={base_filename}_repaired2.fq.gz outs={base_filename}_singletons.fq.gz

clumpify.sh in1={base_filename}_repaired1.fq.gz in2={base_filename}_repaired2.fq.gz out={base_filename}_clumpify_1.fastq out2={base_filename}_clumpify_2.fastq dedupe subs={subs} threads={threads} tmpdir=$TMPDIR

fastp -i {base_filename}_clumpify_1.fastq -I {base_filename}_clumpify_2.fastq -o {base_filename}_qc_1.fastq -O {base_filename}_qc_2.fastq -h {qc_dir}{base_filename}.outreport.html -j {qc_dir}{base_filename}.json -p

minimap2 -c {ref} {base_filename}_qc_1.fastq {base_filename}_qc_2.fastq  > {base_filename}_out_mapping.paf

awk '{{print $1}}' {base_filename}_out_mapping.paf > {base_filename}_out_mapping.txt

filterbyname.sh in1={base_filename}_qc_1.fastq in2={base_filename}_qc_2.fastq out1={clean_dir}{base_filename}_clean_1.fastq out2={clean_dir}{base_filename}_clean_2.fastq names={base_filename}_out_mapping.txt ow=t

rm {base_filename}_repaired1.fq.gz
rm {base_filename}_repaired2.fq.gz
rm {base_filename}_clumpify_1.fastq
rm {base_filename}_clumpify_2.fastq
rm {base_filename}_out_mapping.paf
rm {base_filename}_out_mapping.txt
rm {base_filename}_qc_1.fastq
rm {base_filename}_qc_2.fastq
#mv {input_dir}{base_filename}_R1_001.fastq {raw_dir}
#mv {input_dir}{base_filename}_R2_001.fastq {raw_dir}
"""
    return common_qc_command


# %% Define parameters
parser = argparse.ArgumentParser(description="Quality checking module part of the MRC Metagenomics pipeline",
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
qcArgs = parser.add_argument_group("[2] QC settings")
pbsArgs = parser.add_argument_group("[3] PBS settings")
optionalArgs = parser.add_argument_group("[4] Optional arguments")


# Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                     required=True,
                     help='path to input directory of raw sequences (e.g., fastQ)')
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')
requiredArgs.add_argument('-m', '--manifest',
                     required=True,
                     help="""path to manifest file in .csv format. The header line
is case sensitive, and must follow the following format with no spaces between commas.
    
Sample_ID,FileID_R1,FileID_R2
""")
requiredArgs.add_argument('-e', '--email',
                     required=True,
                     help='PBS setting - email address')


# QC processing settings
## FIXME: removed dupedist option because it failed in the test data with PRJEB13835
#qcArgs.add_argument('-d', '--dupedist',
#                    required=False,
#                    default=12000,
#                    type=int,
#                    help="""Max distance to consider for optical duplicates. Setting 
#used in clumpify.sh from BBTools. [default=%(default)s]
#Higher removes more duplicates but is more likely to remove 
#PCR rather than optical duplicates. This is platform-specific,
#recommendations:
#                       NextSeq      40  (and spany=t)
#                       HiSeq 1T     40
#                       HiSeq 2500   40
#                       HiSeq 3k/4k  2500
#                       Novaseq      12000
#                    """)
qcArgs.add_argument('-s', '--subs',
                    required=False,
                    type=int,
                    default=0,
                    help='Maximum number of substitutions allowed between duplicates used for clumpify.sh from BBTools')
qcArgs.add_argument('-r', '--ref',
                    required=False,
                    default="/srv/scratch/mrcbio/humangenome/GRCh38_latest_genomic.fna",
                    help='file path to reference host genome')


# PBS settings
pbsArgs.add_argument('--mode',
                     required=False,
                     type=str,
                     default='single',
                     help='Mode to generate PBS scripts, currently supports single sample mode only [default=%(default)s]')
pbsArgs.add_argument('-w', '--walltime',
                     required=False,
                     type=int,
                     default=100,
                     help='walltime hours required for PBS job of MODE [default=%(default)s]')
pbsArgs.add_argument('-M', '--mem',
                     required=False,
                     type=int,
                     default=60,
                     help='memory (GB) required for PBS job of MODE [default=%(default)s]')
pbsArgs.add_argument('-t', '--threads',
                     type=int,
                     default=8,
                     help='number of threads for PBS job of MODE [default=%(default)s]')


# Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this help message and exit')
optionalArgs.add_argument('--verbose',
                          action='store_true',
                          default=False,
                          help="turn on will return verbose message (debugging message is set for the moment)")


# %% main entry
if __name__ == '__main__':
    if len(argv) == 1:
        parser.print_help()
        exit(0)
    args = parser.parse_args()

    # %% Parse input
    manifest = args.manifest
    df = pd.read_csv(manifest, skipinitialspace=True,
                     converters={'Sample_ID':str.strip, 
                                 'FileID_R1':str.strip,
                                 'FileID_R2':str.strip})
    file_manifest = df.to_dict('records')
    
    if (args.verbose):
        # set up logger, TODO: split levels later
        logging.getLogger('').setLevel(logging.DEBUG)
    else:
        logging.getLogger('').setLevel(logging.WARNING)
    
    
    
    
    
    # %% Check directoy paths, ensure ends with /
    # TODO: should check that input_dir is absolute path
    input_dir = args.input_dir
    if not input_dir.endswith("/"):
        input_dir += '/'
    
    output_dir = args.output_dir
    if not output_dir.endswith("/"):
        output_dir += '/'
    
    # output will be in 'QC_module' directory
    output_dir += "QC_module/"    
    
    # %% Creates output directories
    logging.info("Setting up output directories ...")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
    cleanreads_dir = "CleanReads"
    clean_path = os.path.join(output_dir, cleanreads_dir)
    os.mkdir(clean_path)
    logging.info(" Created directory [%s]", clean_path)
    
    clean_dir = clean_path
    if not clean_dir.endswith("/"):
        clean_dir += '/'
    
    ## store FastP output
    qcreport_dir = "QCReport"
    qcr_path = os.path.join(output_dir, qcreport_dir)
    os.mkdir(qcr_path)
    logging.info("Created directory [%s]", qcr_path)
    
    qc_dir = qcr_path
    if not qc_dir.endswith("/"):
        qc_dir += '/'
    
    rawreads_dir = "RawReads"
    rawreads_path = os.path.join(output_dir, rawreads_dir)
    os.mkdir(rawreads_path)
    logging.info("Created directory [%s]", rawreads_path)
    
    raw_dir = rawreads_path
    if not raw_dir.endswith("/"):
        raw_dir += '/'
    
    # %% Generate PBS scripts
    # define variables within functions for each function
    logging.info("Generating PBS scripts for [MODE=%s] samples", args.mode)
    
    # TODO: set fixed values for mode, setup single PBS for batch processing
    # and use PBS array jobs
    if (args.mode == 'single'):
        for ID in file_manifest:
            pbs_file = ""
            pbs_file += get_pbs_template_headers(
                ID["Sample_ID"],
                args.threads,
                args.walltime,
                args.mem,
                args.email,
                output_dir)
    
            # if the basefile is zipped then add et_unzip_base_file_command function if not don't add
            ## TODO: delete as clumpify.sh can work on gzipped data
            #if is_gzipped(ID['FileID_R1']):
            #    pbs_file += get_unzip_base_file_command(
            #        input_dir, ID['FileID_R1'], ID['FileID_R2'])
    
            pbs_file += get_common_qc_command(
                input_dir,
                ID["FileID_R1"],
                ID["FileID_R2"],
                ID["Sample_ID"],
                args.subs,
                args.threads,
                #args.dupedist,
                args.ref,
                clean_dir,
                qc_dir,
                raw_dir
            )
    
            pbsFile = f'{output_dir}{ID["Sample_ID"]}.pbs'
            if args.verbose:
                logging.debug("Writing: %s", pbsFile)
            with open(pbsFile, 'w+') as output_file:
                output_file.write(pbs_file)
