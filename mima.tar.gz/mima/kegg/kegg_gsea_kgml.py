#!/usr/bin/env python3

import sys
import os
import numpy
import pandas
import shutil
import csv
import re
import xml.etree.ElementTree
import matplotlib
import matplotlib.pyplot

#######
### modify kgml (KEGG Markup Language) file to visualize gsea outputs
#######
def kegg(de, colrank, linksKP, linksKM, colnamesKP, colnamesKM, pathwayList, koList, moduleList, kgml, scriptPath, out):
    de = de
    colrank = colrank
    linksKP = linksKP
    linksKM = linksKM
    colnamesKP = colnamesKP
    colnamesKM = colnamesKM
    pathwayList = pathwayList
    koList = koList
    moduleList = moduleList
    kgml = kgml
    scriptPath = scriptPath
    out = out
### info of inputs
    print("---------------------\nProcessing...\n")
    print("differential analysis matrix: " + de)
    print("column names for ranking: " + str(colrank))
    print("KEGG links files: " + linksKP)
    print("column names for KEGG links files: " + str(colnamesKP))
    print("KEGG links files: " + linksKM)
    print("column names for KEGG links files: " + str(colnamesKM))
    print("KEGG pathway list: " + pathwayList)
    print("KEGG KO list: " + koList)
    print("KEGG module list: " + moduleList)
    print("KEGG kgml directory: " + kgml)
    print("script path: " + scriptPath)
    print("output directory: " + out + "\n---------------------\n")
### call generateGMT()
### for pathway to ko
    gmt = out + "/IDmapping_" + colnamesKP[1] + "_" + colnamesKP[0] + ".gmt"
### if the gmt file exists, do not need to regenerate it again
    generateGMT(linksKP, colnamesKP, pathwayList, koList, out, gmt)
### for module to ko
    gmtKM = out + "/IDmapping_" + colnamesKM[1] + "_" + colnamesKM[0] + ".gmt"
    generateGMT_KM(linksKM, colnamesKM, moduleList, koList, out, gmtKM)
### call run_gseapy()
    out_gseapy = out + "/gseapy_" + colnamesKP[1] + "_" + colnamesKP[0]
    report_gseapy = out_gseapy + "/gseapy.prerank.gene_sets.report.csv"
### if the report_gseapy file exists, do not need to regenerate it again
    if not os.path.isfile(report_gseapy):
        report_gseapy = run_gseapy(de, colrank, gmt, scriptPath, out_gseapy)
### call enrichedPathways()
    out_kgml = out + "/kgml_" + colnamesKP[1] + "_" + colnamesKP[0]
    enrichedPathways(de, gmt, report_gseapy, colrank, kgml, out_kgml)
### call run_gseapy()
    out_gseapy = out + "/gseapy_" + colnamesKM[1] + "_" + colnamesKM[0]
    report_gseapy = out_gseapy + "/gseapy.prerank.gene_sets.report.csv"
### if the report_gseapy file exists, do not need to regenerate it again
    if not os.path.isfile(report_gseapy):
        report_gseapy = run_gseapy(de, colrank, gmtKM, scriptPath, out_gseapy)
#######

#######
### generate the GMT (Gene Matrix Transposed file format, each row represents a gene set) files
### or GMX (Gene MatriX file format, each column represents a gene set) files
### for pathway to ko
#######
def generateGMT(linksKP, colnamesKP, pathwayList, koList, out, gmt):
    links = linksKP
    colnames = colnamesKP
    pathwayList = pathwayList
    koList = koList
    out = out
    gmt = gmt
### output of 3-level pathway list
    if not os.path.isfile(out + "/pathwayList.txt"):
        pathway = generate3Pathway(pathwayList, out)
    else:
        pathway = pandas.read_csv(out + "/pathwayList.txt", sep = "\t")
### output of KO annotation list
    if not os.path.isfile(out + "/koList.txt"):
        ko = generateKO(koList, out)
    else:
        ko = pandas.read_csv(out + "/koList.txt", sep = "\t")
    print("Processing...generate the GMT (Gene Matrix Transposed file format, each row represents a gene set) files:\n")
### dictionary keys are the second element in colnames (e.g., pathways)
### values are the first element in colnames (e.g., ko)
    IDmapping_df = pandas.read_csv(links, sep = '\t', names = colnames)
    print("dimension of KEGG links files: " + str(IDmapping_df.shape))
    print(IDmapping_df[:10])
    IDmapping_dict = {}
    for i in IDmapping_df[colnames[1]].unique():
        if "path:map" in i:
            continue
        else:
            IDmapping_dict[i[5:]] = [IDmapping_df[colnames[0]][j][3:] for j in IDmapping_df[IDmapping_df[colnames[1]]==i].index]
### sort the keys
    keys = sorted(IDmapping_dict.keys())
### output the GMT file where each row is a gene set
    f = open(gmt, "w", newline = '')
    writer = csv.writer(f, delimiter = "\t")
    for key in keys:
        annotation = pathway.loc[pathway['pathway_ID'] == key]['pathway_name'].values[0]
        writer.writerow([key] + [annotation] + IDmapping_dict[key])
    f.close()
    print("\nComplete: generated gmt file: " + gmt + "\n---------------------\n")
    #return gmt
#######

#######
### generate the GMT (Gene Matrix Transposed file format, each row represents a gene set) files
### for module to ko
#######
def generateGMT_KM(linksKM, colnamesKM, moduleList, koList, out, gmtKM):
    links = linksKM
    colnames = colnamesKM
    moduleList = moduleList
    koList = koList
    out = out
    gmt = gmtKM
### output of KO annotation list
    if not os.path.isfile(out + "/koList.txt"):
        ko = generateKO(koList, out)
    else:
        ko = pandas.read_csv(out + "/koList.txt", sep = "\t")
### output of module list
    if not os.path.isfile(out + "/moduleList.txt"):
        module = generateModule(moduleList, out)
    else:
        module = pandas.read_csv(out + "/moduleList.txt", sep = "\t")
    print("Processing...generate the GMT (Gene Matrix Transposed file format, each row represents a gene set) files:\n")
    IDmapping_df = pandas.read_csv(links, sep = '\t', names = colnames)
    print("dimension of KEGG links files: " + str(IDmapping_df.shape))
    print(IDmapping_df[:10])
    IDmapping_dict = {}
    for i in IDmapping_df[colnames[1]].unique():
        IDmapping_dict[i[3:]] = [IDmapping_df[colnames[0]][j][3:] for j in IDmapping_df[IDmapping_df[colnames[1]]==i].index]
### sort the keys
    keys = sorted(IDmapping_dict.keys())
### output the GMT file where each row is a gene set
    f = open(gmt, "w", newline = '')
    writer = csv.writer(f, delimiter = "\t")
    for key in keys:
        annotation = module.loc[module['module_ID'] == key]['module_name'].values[0]
        writer.writerow([key] + [annotation] + IDmapping_dict[key])
    f.close()
    print("\nComplete: generated gmt file: " + gmtKM + "\n---------------------\n")
#######

#######
### generate 3-level pathway list
#######
def generate3Pathway(pathwayList, out):
    print("---------------------\nProcessing...generate 3-level pathway list:\n")
### import the kegg pathway list
    file = open(pathwayList, 'r')
    lines = file.readlines()
### dataframe to hold the 3-level pathway list
    pathway = pandas.DataFrame(columns = ['pathway_ID', 'pathway_name', 'level_1', 'level_2', 'level_3'])
    for line in lines:
### if this line start with only one "#", it is level 1
        if line.startswith("#") and not line.startswith("##"):
            level1 = line[1:-1]
            #print(level1)
### if this line start with two "##", it is level 2
        elif line.startswith("##"):
            level2 = line[2:-1]
            #print(level2)
### otherwise it is level 3
        else:
            element = line.split("\t")
            #print(element[0] + "\t" + level1 + "\t" + level2 +"\t" + element[1])
### append pathway_ID, level 1, level 2 and level 3 to dataframe
            pathway = pathway.append({'pathway_ID': "ko" + element[0],
                                      'pathway_name': level1 + ";" + level2 + ";" + element[1].rstrip(),
                                      'level_1': level1, 
                                      'level_2': level2, 
                                      'level_3': element[1].rstrip()}, ignore_index = True)
    #print(pathway)
### output dataframe
    pathway.to_csv(out + "/pathwayList.txt", header = True, index = False, sep = '\t', mode = 'w')
    return pathway
#######

#######
### generate KO annotation list
#######
def generateKO(koList, out):
    print("Processing...generate KO annotation list:\n")
### import the kegg pathway list
    file = open(koList, 'r')
    lines = file.readlines()
### dataframe to hold the KO annotation list
    ko = pandas.DataFrame(columns = ['ko_ID', 'ko_name', 'ko_definition', 'EC'])
    entry = name = EC = definition = None
    for line in lines:
### if this line start with "ENTRY", it is ID
        if line.startswith("ENTRY"):
            entry = re.split('\s+', line.rstrip())
            entry = entry[1]
### if this line start with "NAME", it is symbol
        elif line.startswith("NAME"):
            name = re.split('\s+|,\s+', line.rstrip())
            seperator = ";"
            name = seperator.join(name[1:])
### if this line start with "DEFINITION", it is definition
        elif line.startswith("DEFINITION"):
            definition = re.split("\[EC:", line.rstrip())
            if len(definition) > 1:
                EC = re.split("(?<=[0-9])[\s+](?=\d)", definition[1][:-1])
                EC = seperator.join(EC)
            else:
                EC = "NA"
            definition = re.split("\s{2,}", definition[0].rstrip())
            definition = definition[1]
### append to dataframe
            if entry and name and EC and definition:
                ko = ko.append({'ko_ID': entry,
                                'ko_name': name,
                                'ko_definition': definition,
                                'EC': EC}, ignore_index = True)
                entry = name = EC = definition = None
### output dataframe
    ko.to_csv(out + "/koList.txt", header = True, index = False, sep = '\t', mode = 'w')
    return ko
#######

#######
### generate module list
#######
def generateModule(moduleList, out):
    print("Processing...generate module list:\n")
    moduleList = moduleList
    out = out
### import
    file = open(moduleList, 'r')
    lines = file.readlines()
### dataframe to hold the KO annotation list
    module = pandas.DataFrame(columns = ['module_ID', 'module_name', 'module_class'])
    entry = name = clas = None
    for line in lines:
### if this line start with "ENTRY", it is ID
        if line.startswith("ENTRY"):
            entry = re.split('\s+', line.rstrip())
            entry = entry[1]
### if this line start with "NAME", it is symbol
        elif line.startswith("NAME"):
            name = re.split('\s+', line.rstrip())
            seperator = " "
            name = seperator.join(name[1:])
### if this line start with "DEFINITION", it is definition
        elif line.startswith("CLASS"):
            clas = re.split("\s+", line.rstrip())
            seperator = " "
            clas = seperator.join(clas[1:])
### append to dataframe
            if entry and name and clas:
                module = module.append({'module_ID': entry,
                                'module_name': name,
                                'module_class': clas}, ignore_index = True)
                entry = name = clas = None
### output dataframe
    module.to_csv(out + "/moduleList.txt", header = True, index = False, sep = '\t', mode = 'w')
    return module
#######

#######
### run gesapy
#######
def run_gseapy(de, colrank, gmt, scriptPath, out_gseapy):
    de = de
    colrank = colrank
    gmt = gmt
    scriptPath = scriptPath
    out_gseapy = out_gseapy
### info of inputs
    print("---------------------\nProcessing...run gesapy:\n")
    out = out_gseapy
    if not os.path.exists(out):
        os.makedirs(out)
### generate Ranked Gene Lists in rnk format, two columns with 1st and 2nd columns indicate gene ID and numeric values used to rank the genes, respectively
    de = pandas.read_csv(de, sep = "\t")
    rnk = de.loc[:, colrank[:2]]
    rnk.to_csv(out + "/rnk.txt", header = False, index = False, sep = '\t', mode = 'w')
### run gseapy prerank
    myCmd = "gseapy prerank --min-size 5 --max-size 1000 -r " + out + "/rnk.txt -g " + gmt + " -o " + out
    print("Command of gseapy:\n" + myCmd)
    os.system(myCmd)
### output add annotation
    gmt_df = pandas.read_csv(gmt, usecols=[0,1], names = ["ID", "description"], sep = '\t')
    report_df = pandas.read_csv(out + "/gseapy.prerank.gene_sets.report.csv", sep = ',')
    report_df2 = pandas.DataFrame(columns = ["ID", "description"])
    for id in report_df['Term']:
        print(id)
        report_df2 = report_df2.append({'ID': gmt_df.loc[gmt_df['ID'] == id, ['ID']].values[0][0],
            'description': gmt_df.loc[gmt_df['ID'] == id, ['description']].values[0][0]}, ignore_index = True)
    report_df3 = pandas.concat([report_df, report_df2], axis = 1)
    report_df3.to_csv(out + "/gseapy.prerank.gene_sets.report.txt", header = True, index = False, sep = '\t', mode = 'w')
### report columns: es: enrichment score, nes: normalized enrichment score, p: P-value, fdr: FDR, size: gene set size
### matched_size: genes matched to the data, genes: gene names from the data set, ledge_genes: leading edge genes
    report = out + "/gseapy.prerank.gene_sets.report.csv"
    print("\nComplete: gseapy report: " + report + "\n---------------------\n")
    return report

#######
### extract enriched pathways
#######
def enrichedPathways(de, gmt, report_gseapy, colrank, kgml, out_kgml):
    print("---------------------\nProcessing...extract enriched pathways and their kgml files, then modify:\n")
    out = out_kgml
    if not os.path.exists(out):
        os.makedirs(out)
    pathways = pandas.read_csv(report_gseapy, sep = ",")
    gmt = pandas.read_csv(gmt, sep = "\t", usecols = [0, 1], names = ["Term", "description"])
    de = pandas.read_csv(de, sep = "\t")
    fdr = 0.1
    pathways_fdr = pathways.loc[pathways["fdr"] <= fdr]
    pathways_num = 20
    if pathways_fdr.shape[0] < pathways_num:
        pathways_fdr = pathways.iloc[:pathways_num]
    pathways_fdr_gmt = pandas.merge(pathways_fdr, gmt, on = "Term")
    print(pathways_fdr_gmt)
### extract ko (and its p-value) from enriched pathways
    pathways_ko = {}
    for t in pathways_fdr_gmt.loc[:,"Term"]:
### extract matched ko of a pathway as a lit
        genes = str(pathways_fdr_gmt[pathways_fdr_gmt["Term"] == t]["genes"].values[0]).split(";")
### based on the ko list, extract their p-values from de as a dataframe
        genes_pvalue = de.loc[de[colrank[0]].isin(genes), [colrank[0], colrank[1], colrank[2]]]
        genes_pvalue = genes_pvalue.loc[genes_pvalue[colrank[2]] <= 0.5]
### use pathway as key and ko_p-value dataframe as value
        pathways_ko[t] = genes_pvalue
### copy kgml to out directory
        xml_ko, xml_hsa = copy_kgml(t, kgml, out)
### modify the ko xml and hsa xml
        modify_kgml(xml_ko, xml_hsa, genes_pvalue, out)
    #print(pathways_ko)
    print("\nComplete...modify the kgml files:\n---------------------")

#######
### locate and copy the kgml file
#######
def copy_kgml(pathway, kgml, out):
    pathway = pathway + ".xml"
    pathway_hsa = "hsa" + pathway[2:]
    #print(pathway)
    for root, dirs, files in os.walk(kgml):
        if pathway in files:
            xml_ko = os.path.join(root, pathway)
            print(xml_ko)
            shutil.copy2(xml_ko, out)
        if pathway_hsa in files:
            xml_hsa = os.path.join(root, pathway_hsa)
            print(xml_hsa)
            shutil.copy2(xml_hsa, out)
    xml_ko = out + "/" + pathway
    xml_hsa = out + "/" + pathway_hsa
    return xml_ko, xml_hsa

#######
### modify the ko xml and hsa xml
#######
def modify_kgml(xml_ko, xml_hsa, genes_pvalue, out):
### modify dataframe genes_pvalue to normalize adjustedLog2FC into interval [0, 1]
    logfc_max = genes_pvalue["adjustedLog2FC"].values.max()
    logfc_min = genes_pvalue["adjustedLog2FC"].values.min()
### get the max between the absolute value of logfc_max and logfc_min
    logfc_lim = max(abs(logfc_max), abs(logfc_min))
### assign back the signs to logfc_max (normaly a positive number) and logfc_min (normaly a negative number)
    logfc_max = numpy.sign(logfc_max) * logfc_lim
    logfc_min = numpy.sign(logfc_min) * logfc_lim
### now the range is equal between the two sides of zero    
    logfc_range = logfc_max - logfc_min
    if logfc_range == 0:
        logfc_range = 1
    adjustedLog2FC = genes_pvalue["adjustedLog2FC"].values
### simply use a value minus min the devide max
    adjustedLog2FC_norm = (adjustedLog2FC - logfc_min)/logfc_range
### add a new column to dataframe
    genes_pvalue["adjustedLog2FC_norm"] = adjustedLog2FC_norm
### generate a cuntomized color palette
    #cmap = matplotlib.colors.LinearSegmentedColormap.from_list('custom', [(0, 'forestgreen'), (0.5, 'white'), (1,'darkviolet')], N = genes_pvalue.shape[0])
    cmap = matplotlib.colors.LinearSegmentedColormap.from_list('custom', [(0, 'forestgreen'), (0.5, 'white'), (1,'darkviolet')], N = 100)
### check whether the kgml file is there
    if os.path.isfile(xml_ko):
        print(xml_ko)
### Open original file
        xml_ko_tree = xml.etree.ElementTree.parse(xml_ko)
        root = xml_ko_tree.getroot()
### define a dataframe to hold the info of nodes that are differentially expressed (i.e., in the dataframe genes_pvalue) in the kgml
        hsa = pandas.DataFrame(columns = ["entry_ID", "name", "adjustedLog2FC_norm", "color"])
### for every gene in the dataframe
        for gene in genes_pvalue["Row.names"].values:
            flag = 0
### go through all the entry elements in the pathway kgml
            for entry in root.findall("entry"):
### if the gene name is in the entry's name
                if gene in entry.get("name"):
                    flag = 1
### from the dataframe, extract the adjustedLog2FC_norm value of this gene
                    adjustedLog2FC_norm = float(genes_pvalue.loc[genes_pvalue["Row.names"] == gene, ["adjustedLog2FC_norm"]].values[0])
### convert to a hex color
                    new_color = matplotlib.colors.to_hex(cmap(float(adjustedLog2FC_norm)))
### get the entry's id
                    entry_ID = entry.get("id")
### if this entry's id is already in the dataframe has
                    if entry_ID in hsa["entry_ID"].values:
### find the adjustedLog2FC_norm value of the previous node with the same entry id
                        adjustedLog2FC_norm_old = hsa.loc[hsa["entry_ID"] == str(entry_ID), ["adjustedLog2FC_norm"]].values[0][0]
### if adjustedLog2FC_norm of the present and previous nodes are both bigger than 0.5, meaning they are both up-regulated, then take the larger adjustedLog2FC_norm value for both nodes
                        if adjustedLog2FC_norm_old >= 0.5 and adjustedLog2FC_norm >= 0.5:
                            adjustedLog2FC_norm = max(adjustedLog2FC_norm_old, adjustedLog2FC_norm)
### if adjustedLog2FC_norm of the present and previous nodes are both smaller than 0.5, meaning they are both down-regulated, then take the smaller adjustedLog2FC_norm value for both nodes
                        elif adjustedLog2FC_norm_old <= 0.5 and adjustedLog2FC_norm <= 0.5:
                            adjustedLog2FC_norm = min(adjustedLog2FC_norm_old, adjustedLog2FC_norm)
### else, i.e., one is bigger than 0.5 (up-regulated) and another is smaller than 0.5 (down-regulated), then compare their distance to 0.5 and take the one has longer distance to 0.5
                        else:
                            if abs(adjustedLog2FC_norm_old - 0.5) >= abs(adjustedLog2FC_norm - 0.5):
                                adjustedLog2FC_norm = adjustedLog2FC_norm_old
### get the color into hex format
                        new_color = matplotlib.colors.to_hex(cmap(float(adjustedLog2FC_norm)))
### modify the color of the previous node as the new color if needed
                        hsa.loc[hsa["entry_ID"] == entry_ID, ["color"]] = new_color
### append this new entry element to the dataframe
                        hsa = hsa.append({"entry_ID": entry_ID, "name": gene, "adjustedLog2FC_norm": adjustedLog2FC_norm, "color": new_color}, ignore_index = True)
### if this entry's id has no previous record, then just append to the dataframe
                    elif entry_ID not in hsa["entry_ID"].values:
                        hsa = hsa.append({"entry_ID": entry_ID, "name": gene, "adjustedLog2FC_norm": adjustedLog2FC_norm, "color": new_color}, ignore_index = True)
### if flag == 0, meaning this gene is not in the pathway kgml which should not happen
            if flag == 0:
                print(gene)
### modify the kgml, first change the background color of all the nodes to white
        for rank in root.iter("graphics"):
            rank.attrib['bgcolor'] = "#ffffff"
### then for the nodes that has entry id in the dataframe hsa, change their background color to the value in the dataframe
        for entry_ID in hsa["entry_ID"].values:
            for entry in root.findall('entry'):
                if entry.get("id") == entry_ID:
                    entry.find("graphics").attrib["bgcolor"] = hsa.loc[hsa["entry_ID"] == entry_ID, ["color"]].values[0][0]
### output the colored kgml file
        xml_ko_tree.write(xml_ko[:-4] + "_colored.xml")
### generate a colorbar for the kgml file
        colorbar_fig = matplotlib.pyplot.figure(figsize = (4, 2))
        colorbar_ax = colorbar_fig.add_axes([0.05, 0.80, 0.9, 0.15])
        colorbar_limits = matplotlib.colors.Normalize(vmin = round(logfc_min, 1), vmax = round(logfc_max, 1))
        bounds = [round(logfc_min, 1), 0, round(logfc_max, 1)]
        colorbar = matplotlib.colorbar.ColorbarBase(colorbar_ax, cmap = cmap, norm = colorbar_limits, ticks = bounds, orientation = 'horizontal')
        colorbar.set_label('Log2 fold change')
        matplotlib.pyplot.savefig(xml_ko[:-4] + "_colorbar.png", dpi = 1000)
### check whether the kgml file is there
    if os.path.isfile(xml_hsa):
        print(xml_hsa)
        xml_hsa_tree = xml.etree.ElementTree.parse(xml_hsa)
        root = xml_hsa_tree.getroot()
### modify the kgml, first change the background color of all the nodes to white
        for rank in root.iter("graphics"):
            rank.attrib['bgcolor'] = "#ffffff"
### then for the nodes that has entry id in the dataframe hsa, change their background color to the value in the dataframe
### some nodes have different names in xml_ko and xml_hsa, but their entry ids are the same
        for entry_ID in hsa["entry_ID"].values:
            for entry in root.findall('entry'):
                if entry.get("id") == entry_ID:
                    entry.find("graphics").attrib["bgcolor"] = hsa.loc[hsa["entry_ID"] == entry_ID, ["color"]].values[0][0]
### output the colored kgml file
        xml_hsa_tree.write(xml_hsa[:-4] + "_colored.xml")
    print("\n")
