#!/usr/bin/env python3

import sys
import os
import argparse
print("\n---------------------\n*********************\n" +\
	"Warning: please activate conda before running this script\n\n" +\
	"source /srv/scratch/z3527776/tool/miniconda3_20200412/bin/activate /srv/scratch/z3527776/tool/miniconda3_20200412/envs/kegg\n" +\
	"*********************\n---------------------\n")

#######
###	import own modules
#######
import kegg_gsea_kgml as kegg
#######

#######
###	parse command line arguments
#######
parser = argparse.ArgumentParser()
parser.add_argument("--mat", help = "differential analysis output matrix with at least three Essential columns: \
    gene ID, log2 fold change (or other values that can be used to Rank the genes) and p-value (or adjusted p-value)")
parser.add_argument("--matcol", help = "semicolon separated names of the three Essential columns from differential analysis matrix, \
    e.g., \"Row.names;adjustedLog2FC;wil_pval\"")
parser.add_argument("--linksKP", help = "ID mapping files from KEGG Orthology (KO) to PATHWAY,\
    normaly in the directory: kegg-directory/genes/ko/, e.g., ko_pathway.list")
parser.add_argument("--linksKM", help = "ID mapping files from KEGG Orthology (KO) to MODULE,\
    normaly in the directory: kegg-directory/genes/ko/, e.g., ko_module.list")
#parser.add_argument("--colnames", help = "semicolon separated column names for links file, e.g., ko;pathway")
parser.add_argument("--pathwayList", help = "kegg pathway list, used to generate 3-level pathway list, \
    e.g., kegg-directory/pathway/pathway.list")
parser.add_argument("--koList", help = "kegg KO list, used to generate KO annotation list, e.g., kegg-directory/genes/ko/ko")
parser.add_argument("--moduleList", help = "kegg module list, used to generate module list, e.g., kegg-directory/module/module")
parser.add_argument("--kgml", help = "path to the kegg xml files, e.g., kegg-directory/xml/kgml")
parser.add_argument("--out", help = "output directory")
args = parser.parse_args()
#######

#######
###	define the main function
#######
def main(args):
###	differential analysis matrix
    de = args.mat
###	columns from differential analysis matrix that are use to rank gene list
    colrank = args.matcol
    colrank = colrank.split(";")
###	ID mapping files between KEGG DBs
    linksKP = args.linksKP
    linksKM = args.linksKM
###	column names for links file
    colnamesKP = linksKP.split("/")[-1].split(".")[0].split("_")
    colnamesKM = linksKM.split("/")[-1].split(".")[0].split("_")
### script path
    scriptPath = os.path.dirname(__file__)
###	kegg pathway list
    pathwayList = args.pathwayList
###	kegg KO list
    koList = args.koList
### kegg module list
    moduleList = args.moduleList
###	path to the kegg xml files
    kgml = args.kgml
###	output path
    out = args.out
###	check if files exist
    fileList = [de, linksKP, pathwayList, koList]
    if all([os.path.isfile(f) for f in fileList]):
    	print("running...\n")
    	if not os.path.exists(out):
    		os.makedirs(out)
    	kegg.kegg(de, colrank, linksKP, linksKM, colnamesKP, colnamesKM, pathwayList, koList, moduleList, kgml, scriptPath, out)
    else:
    	print("---------------------\nError: please check whether the requied files are prepared\n---------------------\n")
#######

#######
###	run the main function
#######
main(args)
#######