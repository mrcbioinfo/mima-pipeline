import argparse
import os
import pandas as pd


parser = argparse.ArgumentParser()
parser.add_argument('--metadata',
                    required=True,
                    #type=argparse.FileType('r', encoding='UTF-8'),
                    #nargs='+',
                    help='path to metadata file in .csv format')
parser.add_argument('--type', '-f',
                    required=False,
                    type=str,
                    default="fastq",
                    help='file type: fastq, fasta etc')
parser.add_argument('--threads', '-t',
                    type=int,
                    default=8,
                    help='number of threads')
parser.add_argument('--input_dir',
                    required=True,
                    help='file path to input directory of clean sequences (post QC)')


args = parser.parse_args()

metadata=args.metadata
df = pd.read_csv(metadata)
file_metadata = df.to_dict('records')


input_dir=args.input_dir
#if input does not end with
if not input_dir.endswith("/"):
    input_dir += '/'


out_dir = "mpa3"
mpa_path = os.path.join(input_dir, out_dir)
os.mkdir(mpa_path)


def get_mpa_command(input_dir, base_filename, threads, file_type, outdir):
    mpa_command= f"""metaphlan {input_dir}{base_filename}_clean_1.fastq,{input_dir}{base_filename}_clean_2.fastq --bowtie2out {mpa_path}/{base_filename}_metlsagenome.bowtie2.bz2  --nproc {threads} --input_type {file_type} -o {mpa_path}/{base_filename}_metagenome.txt
"""

    return mpa_command

with open(f'{mpa_path}/mpa.tsv', "w+") as output_file:
    for ID in file_metadata:
        filecommands = [get_mpa_command(input_dir, ID["Sample_ID"], args.threads, args.type, mpa_path)]
        print(filecommands)
        output_file.write('\t'.join(str(x) for x in filecommands))

