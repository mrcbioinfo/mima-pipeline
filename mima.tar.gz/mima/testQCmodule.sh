python qc_module_v3.py --metadata ../demo/manifest.csv --input_dir ../demo/00-data/ --output_dir ../out/ -e x.chua@unsw.edu.au
