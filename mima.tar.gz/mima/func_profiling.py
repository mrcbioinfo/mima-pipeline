"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Functional profiling module

This is part of the MRC Metagenomics pipeline. This is the functional 
profiling module that generates PBS scripts for processing multiple samples 
in a study. 

This module has the following profiling modes:

- Humann2
- Humann3

OUTPUT: 1 PBS script per sample file

The pipeline is suitable for metagenomic analyses where samples are processed 
by shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import os
import glob
import logging
import re

from sys import argv
from utils.PathUtils import sanitise_directory_name


# %% Functional profiling commands
def get_humann2_command(input_dir, base_filename, pipeline_dir, threads):
    return f"""
# Merge fastq forward and backward reads
module load JULIA VERSION
julia {pipeline_dir}install.jl
julia {pipeline_dir}combine_fastq.jl {input_dir}{base_filename}_clean_1.fastq {input_dir}{base_filename}_clean_2.fastq {input_dir}{base_filename}_clean.fastq

# Execute HUMAnN2
mkdir -p $(base_filename)
humann2 --input {input_dir}{base_filename}_clean.fastq --output {base_filename} --threads {threads}
"""

## TODO: change to 'cat' command
def get_combine_command(input_dir, base_filename, fwd_suffix, rev_suffix, outdir):
    #return f"""julia combine_fastq.jl {input_dir}{base_filename}_clean_1.fastq {input_dir}{base_filename}_clean_2.fastq {outdir}/{base_filename}_combine.fastq"""
    return f"""cat {input_dir}{base_filename}{fwd_suffix} {input_dir}{base_filename}{rev_suffix} > {outdir}{base_filename}_combine.fastq.gz"""


def get_humann3_command(input_dir, base_filename, threads, fwd_suffix, rev_suffix, outdir):   
    command = "# Execute HUMAnN3\n"
    command += get_combine_command(input_dir, base_filename, fwd_suffix, rev_suffix, outdir)
    command += f"""

outdir=/srv/scratch/mrcgut/XYC/tmp
humann -i {outdir}{base_filename}_combine.fastq.gz --threads {threads} -o $outdir --memory-use maximum

## move all output to output_dir
## mv $TMPDIR/{base_filename}_combine_* {outdir}

rm {outdir}{base_filename}_combine.fastq.gz
"""
    return command


def generate_humann_feature_tables(func_output_dir, email):
    """
    Generates the script to combine all function profiling tables

    :param func_output_dir: directory that consists of the outputs from HUMAnN
    :param email: user email address for PBS script
    """

    feature_table_dir=f"{func_output_dir}featureTables"
    logging.debug(f"Create: {feature_table_dir}")
    os.mkdir(feature_table_dir)

    cmd=f"""
## Merge gene families
humann_join_tables -i {func_output_dir} -o {feature_table_dir}/merge_humann3table_genefamilies.txt -s --file_name genefamilies.tsv

humann_join_tables -i {func_output_dir} -o {feature_table_dir}/merge_humann3table_pathabundance.txt -s --file_name pathabundance.tsv

humann_join_tables -i {func_output_dir} -o {feature_table_dir}/merge_humann3table_pathcoverage.txt -s --file_name pathcoverage.tsv


## Normalise to CPM
humann_renorm_table -i {feature_table_dir}/merge_humann3table_genefamilies.txt -o {feature_table_dir}/merge_humann3table_genefamilies.cpm.txt

humann_renorm_table -i {feature_table_dir}/merge_humann3table_pathabundance.txt -o {feature_table_dir}/merge_humann3table_pathabundance.cmp.txt

humann_renorm_table -i {feature_table_dir}/merge_humann3table_pathcoverage.txt -o {feature_table_dir}/merge_humann3table_pathcoverage.cmp.txt


## Regroup gene families
humann_regroup_table -i {feature_table_dir}/merge_humann3table_genefamilies.cpm.txt -g uniref90_ko -o {feature_table_dir}/merge_humann3table_genefamilies.cmp_uniref90_KO.txt
"""
    ## output PBS script
    pbs_file=f"{feature_table_dir}/generate_func_feature_tables.pbs"
    logging.debug(f"Writing: {pbs_file}")
    with open(pbs_file, 'w') as outfile:
       outfile.write(get_pbs_header('func_table', 28, 12, 32, email, func_output_dir))
       outfile.write(cmd)




## TODO: move common function to utilities file
def get_base_filenames(input_dir, suffix):
    base_files = []
    search_path=f'{input_dir}*{suffix}'
    logging.debug(f"Searching in path [{search_path}]")
    for filename in glob.glob(f'{search_path}'):
        basename = os.path.basename(filename)
        if basename.find(suffix):
            prefix = re.sub(suffix, "", basename)
            base_files.append(prefix)
    return base_files

def get_pbs_header(job_name, threads, walltime, mem, email, working_dir):
    pbs_header = f"""#!/bin/bash
#PBS -N {job_name}
#PBS -l ncpus={threads}
#PBS -l walltime={walltime}:00:00
#PBS -l mem={mem}GB
#PBS -j oe
#PBS -m ae

source ~/myconda
conda activate mima

cd {working_dir}

"""
#PBS -M {email}
    return pbs_header



# %% Define parameters

parser = argparse.ArgumentParser(description='Function profiling module part of the MRC Metagenomics pipeline',
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
funcArgs = parser.add_argument_group("[2] Function profile settings")
pbsArgs = parser.add_argument_group("[3] PBS settings")
optionalArgs = parser.add_argument_group("[4] Optional arguments")


## Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                     required=True,
                     help='path to input directory of cleaned sequences (e.g. QC_module/CleanReads)')
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')
requiredArgs.add_argument('-e', '--email',
                     required=True,
                     help='PBS setting - email address')
        
## Taxonomy profiler
funcArgs.add_argument('--function-profiler',
                     choices=['humann3','humann2'],
                     default='humann3',
                     help="select profiler for function profiling [default=%(default)s]")
funcArgs.add_argument('--fwd-suffix',
                      default='_clean_1.fastq.gz',
		      help='suffix of cleaned reads to search for in input_dir [default=%(default)s]')
funcArgs.add_argument('--rev-suffix',
                      default='_clean_2.fastq.gz',
		      help='suffix of reverse cleaned reads for PBS script [default=%(default)s]')
funcArgs.add_argument('--nucleotide-database',
                      default='/opt/reference/humann/data/chocophlan',
                      help='HUMAnN3 directory containing the nucleotide database [default=%(default)s]')
funcArgs.add_argument('--protien-database',
                      default='/opt/reference/humann/data/uniref',
                      help='HUMAnN3 directory containing the protein database [default=%(default)s]')
funcArgs.add_argument('--pathways-database',
                      default='/opt/reference/humann/data/pathway_database.tsv',
                      help='HUMAnN3 mapping file specifying pathways database [default=%(default)s]')



# PBS settings
pbsArgs.add_argument('--mode',
                     required=False,
                     type=str,
                     default='single',
                     help='Mode to generate PBS scripts, currently supports single sample mode only [default=%(default)s]')
pbsArgs.add_argument('-w', '--walltime',
                     required=False,
                     type=int,
                     default=20,
                     help='walltime hours required for PBS job of MODE [default=%(default)s]')
pbsArgs.add_argument('-M', '--mem',
                     required=False,
                     type=int,
                     default=60,
                     help='memory (GB) required for PBS job of MODE [default=%(default)s]')
pbsArgs.add_argument('-t', '--threads',
                     type=int,
                     default=4,
                     help='number of threads for PBS job of MODE [default=%(default)s]')

## Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this help message and exit')
## TODO: remove argument, using 'cat'
optionalArgs.add_argument('--pipeline-dir',
                    required=False,
                    type=str,
                    default=os.path.dirname(os.path.realpath(__file__)),
                    help='directory of pipeline script for finding combine_fastq.jl')
optionalArgs.add_argument('--verbose',
                    action='store_true',
                    default=False,
                    help="turn on to show verbose messages")
optionalArgs.add_argument('--debug',
                    action='store_true',
                    default=False,
                    help="turn on to show debugging messages")


# %% entry
if __name__ == '__main__':
    if len(argv)==1:
        parser.print_help()
        exit(0)
    args = parser.parse_args()
    print('\n\n--- START ---')
    print(args)
    print('\n---')

    # set up logger, TODO: split levels later
    logging.getLogger('').setLevel(logging.WARNING)
    if args.verbose:
        logging.getLogger('').setLevel(logging.INFO)

    if args.debug:
        logging.getLogger('').setLevel(logging.DEBUG)
    
    
    # %% Check directoy paths, ensure ends with /
    input_dir = sanitise_directory_name(args.input_dir)
    if not os.path.isdir(input_dir):
        logging.error("Input directory does not exist: %s", input_dir)
        exit(3)
    
    output_dir = sanitise_directory_name(args.output_dir)
    output_dir += "Function_profiling/"
    
    pipeline_dir = sanitise_directory_name(args.pipeline_dir)
    
    
    # %% Creates output directories
    logging.info("Setting up output directories ...")
    logging.debug(f"Create: {pipeline_dir}")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
     
    
    # %% Generate PBS scripts
    base_files = get_base_filenames(input_dir, args.fwd_suffix)
    logging.debug(f"Num files found [{len(base_files)}]")
    for basefile in base_files:
        headers = get_pbs_header(f"{basefile}_HumanN2", 
                                 args.threads,
                                 args.walltime,
                                 args.mem,
                                 args.email,
                                 output_dir)
        
        ## TODO: don't put both into forloop
        PROFILERS={'humann2':get_humann2_command(input_dir,
                                                 basefile,
                                                 pipeline_dir,
                                                 args.threads),
                   'humann3':get_humann3_command(input_dir, 
                                                 basefile,
                                                 args.threads,
                                                 args.fwd_suffix,
                                                 args.rev_suffix,
                                                 output_dir)}
        
        pbsFile = f'{output_dir}{basefile}.pbs'
        logging.debug("Writing: %s", pbsFile)
        with open(pbsFile, "+w") as outfile:
            outfile.write(headers)
            outfile.write(PROFILERS[args.function_profiler])

    ## PBS script for generate feature table
    if args.function_profiler == 'humann3':
       logging.debug("Check profiler")
       generate_humann_feature_tables(output_dir, args.email)
