import argparse
import os
import subprocess

from models import TaxonomyProfile, MetadataFile

parser = argparse.ArgumentParser()
parser.add_argument('--data_matrix',
                    required=True,
                    type=argparse.FileType('r', encoding='UTF-8'),
                    nargs='+',
                    help='Path to data matrix file')
parser.add_argument('--metadata',
                    required=True,
                    type=argparse.FileType('r', encoding='UTF-8'),
                    help='Path to the metadata file')
parser.add_argument('--treatment_groups',
                    required=True,
                    help='Comma separated list of treatment groups of interest')
parser.add_argument('--out_dir',
                    required=True,
                    help='Directory for output')

args = parser.parse_args()

treatment_groups = args.treatment_groups.split(',')
data_matrices = args.data_matrix

r_script_path = f'{os.path.dirname(os.path.realpath(__file__))}/visualisation.R'

metadata_file = MetadataFile(args.metadata)
metadata_file.drop_unneeded_fields(treatment_groups)

for matrix in data_matrices:
    tax_profile = TaxonomyProfile.from_unknown_profile_file_format(matrix)
    tax_profile.enrich_matrix_with_metadata(metadata_file.df)

    # Create temporary working directory
    work_dir = os.path.abspath(f'{args.out_dir}/out/{tax_profile.classification_tool}')

    if not os.path.exists(work_dir):
        os.makedirs(work_dir)

    # Write data frame
    tax_profile_meta = f'{work_dir}/TaxProfileWithMeta.txt'
    tax_profile.df.to_csv(tax_profile_meta, sep='\t')

    try:
        print("Rscript: ", r_script_path)
        print("--working_dir", work_dir)
        print("--tax_table", tax_profile_meta)
        print("--num_meta_columns", str(len(treatment_groups)))
        subprocess.check_output(['Rscript', r_script_path,
                                 '--working_dir', work_dir,
                                 '--tax_table', tax_profile_meta,
                                 '--num_meta_columns', str(len(treatment_groups))
                                 ])
    except subprocess.CalledProcessError as e:
        print(e.output)
