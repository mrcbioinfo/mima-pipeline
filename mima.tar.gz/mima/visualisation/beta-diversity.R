# Copyright 2020
# Author: Emily Mc Govern
# Email: emily.mcgovern@unsw.edu.au

generate_ordination_plot <- function(mat, treatment_group, x, y, title,
                                     output_dir, config, xlab=NA, ylab=NA) {
  tryCatch({
      var_x <- ensym(x)
      var_y <- ensym(y)
      filename_prefix  <- gsub(" ", "-", title)
      
      point.size <- ifelse(nrow(mat) <= 20, 3, 2)
      
      ggplot(na.omit(mat), aes(x=!!var_x, y=!!var_y, color=as.factor(get(treatment_group)))) +
        geom_hline(yintercept = 0, colour='grey85') +
        geom_vline(xintercept = 0, colour='grey85') +
        geom_point(shape=16, alpha=.75, size = point.size) +
        stat_ellipse(type='t', show.legend=F) +
        scale_colour_manual(name=treatment_group, values=tail(mrccolors, -22)) +
        labs(title=title, x=ifelse(is.na(xlab), x, xlab), y=ifelse(is.na(ylab), y, ylab)) +
        theme_pubr() +
        theme(aspect.ratio = 1, 
              axis.title = element_text(face='bold'),
              axis.title.x = element_text(size=config$beta.x.axis$title.size,
                                          margin=margin(t=3, unit='mm')),
              axis.title.y = element_text(size=config$beta.y.axis$title.size,
                                          margin=margin(r=3, unit='mm')),
              axis.text.x = element_text(size=config$beta.x.axis$text.size),
              axis.text.y = element_text(size=config$beta.y.axis$text.size),
              panel.grid.minor = element_blank(),
              plot.title = element_text(face=config$beta.title$face, size=config$beta.title$size),
              legend.position = config$beta.legend$position,
              legend.text = element_text(size=config$beta.legend$text.size))
      
      figFile <- paste0(output_dir, filename_prefix, "-", treatment_group, ".", config$beta.fig$ext)
      flog.debug("Beta > Plotting: %s", basename(figFile))
      ggsave(figFile, 
             width = config$beta.fig$width, 
             height= config$beta.fig$height, 
             units = config$beta.fig$units, 
             dpi = 320)
    },
    error=function(cond) {
      flog.error(sprintf("Beta > Error processing %s", treatment_group), file = stderr())
      flog.error(sprintf("Beta > Error %s", cond), file = stderr())
      
      write(sprintf("Error processing %s", treatment_group), file = stderr())
      write(sprintf("Error %s", cond), file = stderr())
    },
    warning=function(cond) {
    },
    finally={
    }
  )
}


generate_cca_plot <- function(treatment_group, microbial_variables, meta_taxa, output_dir, config) {
  flog.debug("Beta > Generating CCA plot ...")
  cca <- cca(microbial_variables ~ get(treatment_group), data=meta_taxa)
  cca_sam_sco <- as.data.frame(scores(cca, display = "sites"))
  meta_taxa[meta_taxa==""]  <- NA
  cca_data <- merge(meta_taxa, cca_sam_sco, by="row.names", all.x=TRUE)
  generate_ordination_plot(cca_data, treatment_group, 
                           "CCA1", "CA1", "CCA Bray Curtis", output_dir, config)
}

generate_rda_plot <- function(treatment_group, microbial_variables, meta_taxa, output_dir, config) {
  flog.debug("Beta > Generating RDA plot ...")
  rda <- rda(data.matrix ~ get(treatment_group), meta_taxa)
  rda_sam_sco <- as.data.frame(scores(rda, display = "sites"))
  meta_taxa[meta_taxa==""]  <- NA
  rda_data <- merge(meta_taxa, rda_sam_sco, by="row.names", all.x=TRUE)
  generate_ordination_plot(rda_data, treatment_group, 
                           "RDA1", "PC1", "RDA Bray Curtis", output_dir, config)
}

generate_dca_plot <- function(treatment_group, microbial_variables, meta_taxa, output_dir, config) {
  flog.debug("Beta > Generating DCA plot ...")
  dca <- decorana(microbial_variables)
  dca_sam_sco <- vegan::scores(dca, display = "sites")
  meta_taxa[meta_taxa==""]  <- NA
  dca_data<-merge(meta_taxa, dca_sam_sco, by="row.names", all.x=TRUE)
  generate_ordination_plot(dca_data, treatment_group, 
                           "DCA1", "DCA2", "DCA Bray Curtis", output_dir, config)
}

generate_pca_plot <- function(treatment_group, microbial_variables, meta_taxa, output_dir, config){
  flog.debug("Beta > Generating PCA plot ...")
  pca <- prcomp(microbial_variables)
  pca.summary <- summary(pca)
  pca_sam_sco <- as.data.frame(scores(pca, display = "sites"))
  meta_taxa[meta_taxa==""]  <- NA
  pca_data <- merge(meta_taxa, pca_sam_sco, by="row.names", all.x=TRUE)
  generate_ordination_plot(pca_data, treatment_group, 
                           "PC1", "PC2", "PCA Bray Curtis", output_dir, config,
                           xlab=sprintf("PC1 (%.2f%% variance explained)", 
                                        pca.summary$importance[2,1]*100),
                           ylab=sprintf("PC2 (%.2f%% variance explained)", 
                                        pca.summary$importance[2,2]*100))
}

generate_ca_plot <- function(treatment_group, microbial_variables, meta_taxa, output_dir, config){
  flog.debug("Beta > Generating CA plot ...")
  hell.mat <- decostand(microbial_variables, "hellinger")
  ca <- cca(hell.mat)
  ca_sam_sco <- as.data.frame(scores(ca, display = "sites"))
  meta_taxa[meta_taxa==""]  <- NA
  ca_data <- merge(meta_taxa, ca_sam_sco, by="row.names", all.x=TRUE)
  generate_ordination_plot(ca_data, treatment_group, 
                           "CA1", "CA2", "CA Bray Curtis", output_dir, config)
}


generate_nmds_plot <- function(treatment_group, microbial_variables, meta_taxa, output_dir, config){
  flog.debug("Beta > Generating NMDS plot ...")
  
  # metaMDS takes either a distance matrix or your community matrix (then requires method for 'distance=')
  
  ## k is the number of dimensions
  NMDS <- metaMDS(microbial_variables, distance="bray", k=2, trymax=35, autotransform=TRUE) 
  #stressplot(NMDS)
  nmds_sam_sco <- as.data.frame(scores(NMDS, display = "sites"))
  meta_taxa[meta_taxa==""]  <- NA
  nmds_data <- merge(meta_taxa, nmds_sam_sco, by="row.names", all.x=TRUE)
  
  generate_ordination_plot(nmds_data, treatment_group, 
                           "NMDS1", "NMDS2", "NMDS Bray Curtis", output_dir, config)
}


# PCA converts correlations/lack of correlation between samples to a 2D plot - 
# highly correlated cells cluster together. Use ape::pcoa to compute principal 
# coordinate decomposition (also called classical scaling) of a distance matrix
generate_pcoa_plot <- function(treatment_group, meta_taxa, distance_matrix, output_dir, config){
  flog.debug("Beta > Generating PCoA plot ...")
  meta_taxa[meta_taxa==""]  <- NA
  PCO = pcoa(distance_matrix)
  
  #extract first and second axis for 2D plot
  pcoa_scores <- as.data.frame(PCO$vectors)
  plot.2D <- data.frame(pcoa_scores[c(1:3)])
  
  #merge with metadata
  pcoa_data <- merge(meta_taxa, plot.2D, by="row.names", all.x=TRUE)
  generate_ordination_plot(pcoa_data, treatment_group, 
                           "Axis.1", "Axis.2", "PCoA Bray Curtis", output_dir, config,
                           xlab=sprintf("PCo1 (%.1f%% variance explained)", 
                                        100*(PCO$values$Eigenvalues/sum(PCO$values$Eigenvalues))[1]),
                           ylab=sprintf("PCo2 (%.1f%% variance explained)", 
                                        100*(PCO$values$Eigenvalues/sum(PCO$values$Eigenvalues))[2]))
}



generate_permanova_table <- function(meta_taxa, distance_matrix, output_dir){
  adonis.results <- lapply(colnames((meta_taxa)), function(x){
    form <- as.formula(paste("distance_matrix", x, sep="~"))
    z <- adonis(form, data = meta_taxa, distance = "bray", permutations=999)
    return(as.data.frame(z$aov.tab)) #convert anova table to a data frame
  }
  )


  names(adonis.results) <- colnames(meta_taxa)
  adonis.results  <- do.call(rbind, adonis.results)
  adonis.results<-adonis.results[1:(ncol(meta)*3),]
  write.table(adonis.results, paste(output_dir, "adonis.results.tsv", sep =""), quote = F , sep = "\t")
}


generate_pairwise_permanova_table <- function(treatment_groups, meta_taxa, distance_matrix, output_dir){
  #pairwise comparisons between groups
  for (treatment_group in treatment_groups){
    pairwise_adonis<-pairwise.adonis(distance_matrix, as.factor(otu_m[,c(treatment_group)]))
    write.table(pairwise_adonis, paste(output_dir, treatment_group, "_", "pairwise_adonis.results.tsv",sep =""), quote = F ,sep = "\t")
  }
}



generate_beta_diversity <- function(treatment_groups, microbial_variables, meta_taxa, output_dir, ini){
  flog.info("Running Beta diversity plots and tests ...")
  
  ## TODO: reference for square root transformation prior to Bray-Curtis
  ##       dissimilarity calculation
  sqrt.mat<-sqrt(microbial_variables)
  flog.debug("Beta > Set seed(36)")
  set.seed(36) #reproducible results
  distance_matrix <- vegdist(sqrt.mat, method='bray')
  
  permanova_output <- paste0(output_dir, "permanova/")
  plots_output = paste0(output_dir, "plots/")
  flog.debug("Beta > Creating subdirectories ...\n\t%s\n\t%s", 
             basename(permanova_output), 
             basename(plots_output))
  dir.create(permanova_output, showWarnings = FALSE)
  dir.create(plots_output, showWarnings = FALSE)


  # generate_permanova_table(meta_taxa, distance_matrix, permanova_output)
  for (treatment_group in treatment_groups){
    flog.debug("Beta > Study group: %s", treatment_group)
    generate_pairwise_permanova_table(treatment_groups, meta_taxa, distance_matrix, permanova_output)
    generate_pcoa_plot(treatment_group, meta_taxa, distance_matrix, plots_output, config)
    generate_cca_plot(treatment_group, microbial_variables, meta_taxa, plots_output, config)
    generate_rda_plot(treatment_group, microbial_variables, meta_taxa, plots_output, config)
    generate_dca_plot(treatment_group, microbial_variables, meta_taxa, plots_output, config)
    generate_pca_plot(treatment_group, microbial_variables, meta_taxa, plots_output, config)
    generate_ca_plot(treatment_group, microbial_variables, meta_taxa, plots_output, config)
    generate_nmds_plot(treatment_group, microbial_variables, meta_taxa, plots_output, config)
  }  
}
