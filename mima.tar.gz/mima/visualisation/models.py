"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Visualisation module

Helper classes for managing taxonomy profiles.

The pipeline is suitable for metagenomic analyses where samples are processed by
shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import io
import pandas as pd


class TaxonomyProfile:

    def __init__(self, tax_matrix, classification_tool):
        '''
        Takes a taxonomic matrix and appends metadata to it.
        Parameter is tax matrix in expected format. See classmethods
        for reading from common formats.
        '''
        self.df = tax_matrix
        self.classification_tool = classification_tool

    @classmethod
    def from_unknown_profile_file_format(cls, tax_file):
        # In case method is called with path rather than file object
        if not isinstance(tax_file, io.IOBase):
            tax_file = open(tax_file, 'r')
        cells = tax_file.readline().split('\t')
        tax_file.close()
        
        ## TODO: make agnostic just accept feature table, don't check
        ##       which tool was used
        if cells[0] == '# IGGsearch species table\n':
            return cls.from_igg_file(tax_file.name)
        elif cells[0] == 'ID':
            return cls.from_metaphalan_file(tax_file.name)
        elif cells[0] == '':
            return cls.from_kraken_file(tax_file.name)
        elif cells[0] == '# Pathway':
            return cls.from_humann_file(tax_file.name)
        elif cells[0] == '# Gene':
            return cls.from_humann_file(tax_file.name)
        else:
            raise ValueError('Could not detect data matrix format')

    @classmethod
    def from_igg_file(cls, tax_file):
        df = pd.read_table(tax_file, header=1, index_col=0)
        df.drop('taxonomy', axis=1, inplace=True)
        df = df.transpose()
        df.columns.names = ['ID']
        return cls(df, 'IGG')

    @classmethod
    def from_kraken_file(cls, tax_file):
        df = pd.read_table(tax_file, header=0, index_col=0)
        df.columns = list(map(lambda col_name: col_name.replace('.report', ''), df.columns))
        df = df.transpose()
        df.columns.names = ['ID']
        return cls(df, 'Kraken')

    @classmethod
    def from_metaphalan_file(cls, tax_file):
        df = pd.read_table(tax_file, header=0, index_col=0)
        df.columns = list(map(lambda col_name: col_name.replace('_metagenome', ''), df.columns))
        df = df.transpose()
        return cls(df, 'Metaphlan')

    @classmethod
    def from_humann_file(cls, tax_file):
        df = pd.read_table(tax_file, header=0, index_col=0)
        df.columns = list(map(lambda col_name: col_name.replace('_combine_Abundance', ''), df.columns))
        df = df.transpose()
        return cls(df, 'Humann')

    def enrich_matrix_with_metadata(self, metadata_df):
        col_list = self.df.columns.values.tolist()
        col_list[0:0] = list(metadata_df.columns.values.tolist())
        self.df = self.df.join(metadata_df[metadata_df.columns.values])
        self.df = self.df[col_list]


class MetadataFile:

    def __init__(self, file):
        if (file.name.endswith('csv')):
            self.df = pd.read_csv(file.name, header=0, index_col=0)
        else:
            print("Reading TSV")
            self.df = pd.read_table(file.name, header=0, index_col=0)

    def drop_unneeded_fields(self, remaining_fields):
        self.df.drop(self.df.columns.difference(remaining_fields), axis=1, inplace=True)
