#!/bin/bash

module load R/4.0.2

indir=/srv/scratch/z3534482/examples/mock_output/Taxonomy_profiling/featureTables
infile=$indir/bracken_FT_genus_relAbund.mod
metadata=/srv/scratch/z3534482/29_MRC_Pipelines/example_data/Tourlousse_mock_community/ss_metadata.tsv

outdir=/srv/scratch/z3534482/examples/mock_output/Visualisation

echo
echo '--- start ---'
echo
echo $outdir

cmd="perl taxa_plot_v2.pl $infile $metadata lab:labA:labB:labC $outdir labs_ 7 8 5"

echo
echo $cmd
echo
eval $cmd
echo '--- end perl ---'

ls -lh $outdir

echo '--- fin ---'
echo

#perl taxa_plot_v2.pl <taxa.tsv> <meta.data.tsv> <Group_Vectors_to_Compare> <output_dir> <outputprefix> <top_N> <figure_width> <figure_heigth>
#        taxa.csv        this is the taxa table
#        meta.data.tsv   this is the meta data table with group information
#        Group_Vectors_to_Compare        Groups to draw ColumnGroup:Subg1:Subg2
#        output_dir      output directory string
#        top_N   Top N taxa shown in the stack bar plot
#        figure_width    output figure width
#        figure_heigth   output figure height

