# Copyright 2020
# Author: Emily Mc Govern
# Email: emily.mcgovern@unsw.edu.au

library(tibble)
source("./variance-stats.R")

generate_alpha_diversity_for_group <- function(treatment_group, microbial_variables, metadata, output_dir, config){
  ##alpha diversity using otusummary
  #   allBio - The alpha diversity indices for the whole community
  # abundBio - The alpha diversity indices for the abundant population
  #  rareBio - The alpha diversity indices for the rare biosphere
  
  flog.debug("Alpha > Calculate alpha diversity for group...")
  
  trans_datamatrix <- t(microbial_variables)
  suppressMessages(rawalpha <- alphaDiversity(otutab = trans_datamatrix, 
                                              siteInCol = TRUE, 
                                              taxhead = "taxonomy", 
                                              threshold = 1, 
                                              percent = FALSE, 
                                              write = FALSE))
  alpha <- rawalpha$allBio
  
  outFile <- paste0(output_dir, "alpha_diversity_raw_data.txt")
  flog.debug("Alpha > Writing: %s", basename(outFile))
  write.table(alpha, outFile, quote = F, sep = "\t")  
  
  generate_variance_stats(alpha, metadata, output_dir, config)
}

generate_alpha_diversity <- function(microbial_variables, metadata, output_dir, config){
  flog.info("Running Alpha diversity plots and tests ...")
  treatment_groups = colnames(metadata)
  for (treatment_group in treatment_groups){
    flog.debug("Alpha > Study group: %s", treatment_group)
    generate_alpha_diversity_for_group(treatment_group, microbial_variables, metadata, output_dir, config)
  }
}
