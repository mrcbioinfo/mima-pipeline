#Pkg.add(ArgParse)
#Pkg.add(DataStructures)
#import Pkg
using DataStructures 
using ArgParse 

#This julia script merge a groups of krakenuniq output into a merged output for multi-samples comparisons 
#Written by Xiao-Tao Jiang: 2019-11-20
#Email biofuture.jiang@gmail.com 

NCBI_RANKS_TYPES = ["superkingdom",
"kingdom",
"phylum",
"class",
"order",
"family",
"genus",
"species",
"no rank",
"species group",
"species subgroup",
"subclass",
"subfamily",
"subgenus",
"subkingdom",
"suborder",
"subphylum",
"subspecies",
"tribe",
"forma",
"varietas"]

##store the rands into dictionary 
selectedRanks = Dict([("superkingdom", 1), ("phylum", 2), ("class", 3), ("order", 4), ("family", 5), ("genus", 6), ("species", 7)])


function parse_commandline()
	s = ArgParseSettings("This program process multipile KrakenUniq output report to generate a merged taxonomy table with 7 ranks format, and relative abundance table for each rank from superkingdom to species Written by Xiao-Tao Jiang: 2019-11-20 Email biofuture.jiang@gmail.com\n",
			     
			     commands_are_required = false,
			     version = "1.0",
	                     add_version = true)


	@add_arg_table s begin
	"--input", "-i"
		help="the input directory for all the krakenuniq reports"
		arg_type = String
		default = "."
	"--output", "-o"
		help = "Output directory store all results"
		required = true
	end
	return parse_args(s)
end

function main()
	parsed_args = parse_commandline()
	inputdir = parsed_args["input"]
	outputdir = parsed_args["output"]
	if isdir("$outputdir")
	else
		mkdir("$outputdir")
	end		
	
	full_selectrank_table(inputdir, outputdir)
###

	rank_taxa_table(inputdir, outputdir, 1)
	rank_taxa_table(inputdir, outputdir, 2)
	rank_taxa_table(inputdir, outputdir, 3)
	rank_taxa_table(inputdir, outputdir, 4)
	rank_taxa_table(inputdir, outputdir, 5)
	rank_taxa_table(inputdir, outputdir, 6)
	rank_taxa_table(inputdir, outputdir, 7)
	rank_taxa_table(inputdir, outputdir, 8)
	rank_taxa_table(inputdir, outputdir, 9)
	rank_taxa_table(inputdir, outputdir, 10)
	rank_taxa_table(inputdir, outputdir, 11)
	rank_taxa_table(inputdir, outputdir, 12)
###
end 


function full_selectrank_table(inputdir, outputdir)
	#dict's dict for tax sample abundance 
	fulltaxasample = DefaultDict(Dict)
	
	outputfile = "$outputdir/Taxa_7_ranks_merge_table.txt"
	ofile = open(outputfile, "w")
	
	files = readdir("$inputdir")
	backupdir = pwd()
	cd(inputdir) ##go to the dirctory have the reports 
	samplesorder = []
	for f in files
		if occursin(r".report$", f) == true		
			push!(samplesorder, f)
			if(isfile(f))

				taxa_array = ["","","","","","",""]
				open(f) do filehandle
					while !eof(filehandle)
						x = readline(filehandle)
						if(occursin(r"^#", x) || x == "") 
							continue 
						end 
						items = split(x, "\t")

						##code block to preserve the full lineage 
						if haskey(selectedRanks, items[8])
							#init taxa_array 
							if(selectedRanks[items[8]] == 1)
								##superkingdom refresh the taxa array 
								taxa_array = ["","","","","","",""]
							end
							#println(items[8])
							#println(selectedRanks[items[8]])
							items[9] = lstrip(items[9])
							mtaxa = ofulltaxa(taxa_array, items[9], selectedRanks[items[8]])
							fulltaxasample[mtaxa][f] = items[1]
							#println(mtaxa)
							##update taxa_array
							taxa_array[selectedRanks[items[8]]] = items[9]
						end 
					end
				end
			end
		end
	end
	cd(backupdir)	
	headname = join(samplesorder, "\t")
	write(ofile, "\t$headname\n")
	#sort(collect(zip(values(dictionary1),keys(dictionary1))))
	for (k1) in  sort(collect(keys(fulltaxasample)))
		v1 = fulltaxasample[k1]
		kstrip = lstrip(k1) ##remove the leading space to keep the name 
		write(ofile, "$kstrip")
		for i in 1:length(samplesorder)
			if haskey(fulltaxasample[k1], samplesorder[i])
				v2 = fulltaxasample[k1][samplesorder[i]]
				write(ofile, "\t$v2")
			else
				write(ofile,"\t0")
			end
		end
		write(ofile, "\n")
	end 
	close(ofile)
end

function ofulltaxa(taxa_array,  taxaname, ranksvalue)
	 taxa_array[ranksvalue] = taxaname  ##init the array value  
	 omerge = [] #array to store the taxa lineage information
	 for i in 1:ranksvalue
		 if (taxa_array[i] != "")
			 #taxa_array[i] = lstrip(taxa_array[i])
			 otaxa = join([i, taxa_array[i]], "_")
			 #println(otaxa)
			 push!(omerge, otaxa)
		 end 
	 end
	 return join(omerge, "|")	 

end 

function rank_taxa_table(inputdir, outputdir, ranks)

	#dic's dict for tax-sample -> abundance 	
	taxasample = DefaultDict(Dict) ##dict's dict
	ranks = NCBI_RANKS_TYPES[ranks]
	fname = replace(ranks, r"\s+" => s"")
	outputfile = "$outputdir/Taxa_$fname.txt"
	ofile = open(outputfile, "w")
	#the output will be a merged file with all ranks, the subdir contains each of ranks 	
	files = readdir("$inputdir")
	backupdir = pwd()
	cd(inputdir) ##go to the dirctory have the reports 
	samplesorder = []
	for f in files
		if occursin(r".report$", f) == true		
			push!(samplesorder, f)
			if(isfile(f))
				open(f) do filehandle
					while !eof(filehandle)
						x = readline(filehandle)
						if(occursin(r"^#", x) || x == "") 
							continue 
						end 
						items = split(x, "\t")
						len = length(items)
						if(items[8] == ranks)
							taxasample[items[9]][f] = items[1]
						end 
					end
				end	
			end
		end
	end
	cd(backupdir)
	headname = join(samplesorder, "\t")
	write(ofile, "\t$headname\n")
	for (k1, v1) in  taxasample
		kstrip = lstrip(k1) ##remove the leading space to keep the name 
		write(ofile, "$kstrip")
		for i in 1:length(samplesorder)
			if haskey(taxasample[k1], samplesorder[i])
				v2 = taxasample[k1][samplesorder[i]]
				write(ofile, "\t$v2")
			else
				write(ofile,"\t0")
			end
		end
		write(ofile, "\n")
	end 
	close(ofile)
end

##main program 
main()
