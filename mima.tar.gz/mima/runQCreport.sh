cmd="python3 qc_report.py --input-dir /srv/scratch/z3534482/examples/output/QC_module --output-dir /srv/scratch/z3534482/examples/output --manifest /srv/scratch/z3534482/examples/15_PRJEB13835/metadata/mini_manifest.csv --debug"

echo
echo
echo $cmd
exec $cmd

