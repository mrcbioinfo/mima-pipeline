#!/usr/bin/perl -w
#use strict;

die "perl $0 <input_matrix> <metadata> <out_dir>\n" unless (@ARGV == 3);
die "$!\n" unless open(I, "$ARGV[0]");
unless(-d "$ARGV[2]"){
	`mkdir $ARGV[2]`;
}

my $head = <I>; chomp($head);
my @filehandles = ();
my @filenames = ();
for(my $i =1; $i <= 8; $i++){

	my $filename = "$ARGV[2]/Taxa_levels_$i.txt";
	my $fileHandle = "LEVEL$i";

	push @filenames, $filename;
	push @filehandles, $fileHandle; 
	die "$!\n" unless open($fileHandle, ">$filename");
	print $fileHandle "$head\n";
}

#print @filehandles;
while(<I>){
	chomp;
	my @m = split /\t/;
	my @n = split(/\|/, $m[0]);
	my $name = $n[-1];
	my $o = join("\t", $name, @m[1..$#m]);
	if($#n == 0){
		my $fileHandle = $filehandles[0];
		print $fileHandle  "$o\n";
	}	
	if($#n == 1){
		my $fileHandle = $filehandles[1];
		print $fileHandle  "$o\n";
	}
	if($#n == 2){
		my $fileHandle = $filehandles[2];
		print $fileHandle "$o\n";
	}
	if($#n == 3){
		my $fileHandle = $filehandles[3];
		print $fileHandle "$o\n";
	}
	if($#n == 4){
		my $fileHandle = $filehandles[4];
		print $fileHandle "$o\n";
	}
	if($#n == 5){
		my $fileHandle = $filehandles[5];
		print $fileHandle "$o\n";
	}
	if($#n == 6){
		my $fileHandle = $filehandles[6];
		print $fileHandle "$o\n";
	}
	if($#n == 7){
		my $fileHandle = $filehandles[7];
		print $fileHandle "$o\n";
	}
}
close I;
