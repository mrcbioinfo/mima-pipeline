indir=/srv/scratch/z3534482/29_MRC_Pipelines/example_data/Tourlousse_mock_community
outdir=/srv/scratch/z3534482/examples/mock_output/

#cmd="python3 qc_module.py -i ${indir}/00-data/ -o $outdir -m ${indir}/manifest.csv -e x.chua@unsw.edu.au --walltime 2 --threads 28 --verbose"

cmd="python3 qc_report.py --input-dir ${outdir}/QC_module --output-dir ${outdir} --manifest ${indir}/manifest.csv --debug"

echo
echo
echo $cmd
exec $cmd

