#!/usr/bin/perl -w
use strict; 

#This is for automatic LEfSe for many groups of comparisions
#dependence LEfSe, biom 
##This script compare all groups in a given enviroment 
#Input1: A big talbe with all samples as column and row as features
#Input2: A meta data file used to do LEfSe analysis
#Input3: A vector indicating the groups chosed to do the analysis: this verctor can be a small fraction of the samples

die "perl $0 <table.tsv> <meta.data.tsv> <Group_Vectors_to_Compare> <output_dir> <outputprefix>\n
Examples:perl All_LEfSe_Comparisons_add_signature_tables.pl merge_taxonomy_rename.txt  meta_data_stool.txt Group:Control:NAFLD:NAFLD-HCC outputdir prefix 
#This is for automatic LEfSe for many groups of comparisions
#dependence LEfSe, biom 
##This script compare all groups in a given enviroment 
#Input1: A big talbe with all samples as column and row as features
#Input2: A meta data file used to do LEfSe analysis
#Input3: A vector indicating the groups chosed to do the analysis: this verctor can be a small fraction of the samples
" unless (@ARGV == 5);

##read the vector to decide which samples are chosen 
my $VEC = $ARGV[2]; ##The vector should metadatacolumn:Group1:Group2:Group3 
my $META = $ARGV[1];
my $TABLE = $ARGV[0];
my $oprefix = $ARGV[4];
unless(-d "$ARGV[3]"){
	`mkdir $ARGV[3]`;
}

my $ODIR = $ARGV[3];
my $fout1 = "$ODIR/$oprefix.select.table.txt";
my %sidg;
my $olog = "$ODIR/log.txt";
die "$!\n" unless open(LOG, ">$olog");

fetech_samples_group($META,$VEC,$fout1,\%sidg);
my $foutforlefse = "$ODIR/$oprefix.select.lefse.txt";
prepare_LEfSe_tables($TABLE, $fout1, \%sidg, $foutforlefse, $ODIR);
lefse($foutforlefse, $ODIR, $oprefix);
my $signaturetable = "$ODIR/$oprefix.signature.table.forbetadiv.txt";
my $filtersig = "$ODIR/lefse/$oprefix.filter.res";
signature_table($filtersig, $foutforlefse, $signaturetable);

sub signature_table{
	#
	my ($fs, $ft, $fo) = @_;
	#Store all the signatures name and group information 
	my %sig = ();
	die "$!\n" unless open(LEFSE, "$fs");
	die "$!\n" unless open(FO, ">$fo");
	while(<LEFSE>){
		chomp;
		my @tem = split /\s+/;
		#	my @formatname = split("_", $tem[0]);
		#	my $repname = join("-", $formatname[0], $formatname[1]);
		$sig{$tem[0]} = 1;
	}
	close LEFSE;

	die  "$!\n" unless open(FTAB, "$ft");
	my $head = <FTAB>;
	print FO $head;
	while(<FTAB>){
		chomp;
		my @m = split /\t/;
		$m[0] =~ s/\|/\./g;
		#my @n = split(/\:/, $m[0]);
		if(exists $sig{$m[0]}){
			print FO "$_\n";
			delete($sig{$m[0]});
		}
	}
	close FTAB;
	
	my @check = keys %sig;
	if($#check != 0 ){
		for my $k (keys %sig){
			print "$k\t$sig{$k}\n";
		}
	
	} 

}


##run LEfSe analysis for this pair 
sub lefse{
	#
	my ($input, $odir) = @_;
	unless(-d "$odir/lefse"){ `mkdir $odir/lefse`;} 
	my $fmt = "$odir/lefse/$oprefix.fmt";
	my $res = "$odir/lefse/$oprefix.res";
	my $filres = "$odir/lefse/$oprefix.filter.res";
	my $resplot = "$odir/lefse/$oprefix.res.pdf";
	my $cladoplot = "$odir/lefse/$oprefix.clado.pdf";
	my $zipfeature = "$odir/lefse/$oprefix.feature.zip";
	
	print LOG "lefse-format_input.py $input $fmt -c 2 -u 1\n";
	print LOG "run_lefse.py $fmt $res\n";
	`lefse-format_input.py $input $fmt -c 2 -u 1 -o 1000000`;
	#`lefse-format_input.py $input $fmt -c 2 -u 1`;
	`run_lefse.py $fmt $res -l 0.5`;
	die "$!\n" unless open(TEM, "$res");
	die "$!\n" unless open(TOUT, ">$filres");
	while(<TEM>){
		chomp;
		my @m = split /\t/;
		my $flag = 1;
		for  my $element (@m){
			if($element eq "" || $element eq "-"){
				$flag =0;
			}
		}

		if($flag == 1){
			print TOUT "$_\n";
		}
	}
	close TEM;close TOUT;
	print LOG "lefse-plot_res.py $filres $resplot --format pdf --left_space 0.35\n";
	print LOG "lefse-plot_cladogram.py $filres $cladoplot --format pdf --max_lev 7\n";
	print LOG "lefse-plot_features.py $fmt $filres $zipfeature --archive zip -f diff --width 12 --height 10 --dpi 300 --format png\n";
	`lefse-plot_res.py $filres $resplot --format pdf`;
	`lefse-plot_cladogram.py $filres $cladoplot --format pdf --max_lev 7`;
	`lefse-plot_features.py $fmt $filres $zipfeature --archive zip -f diff --width 15 --height 10 --dpi 300 --format png`;

	##generating the signature table by the names 
	

}

##convert table into biom and use biom to subset the table and then adding the categry information to the target table for LEfSe analysis 
sub prepare_LEfSe_tables{

	##using biom 
	#conda activate ampliconanalysis 
	
	my ($tsvtable, $selsampleid, $sidg, $tablelefse, $odir) = @_;
	#convert table into biom 
	#die "$odir\n";
	unless(-d "$odir/temp"){`mkdir $odir/temp`;}
	my $tablebiom = "$odir/temp/table.biom";
	my $tableselbiom = "$odir/temp/tablesel.biom";
	my $tablesel = "$odir/temp/tablesel.txt";
	#biom convert -i merge_taxonomy.txt -o test.biom --table-type "Taxon table"
	`biom convert -i $tsvtable -o $tablebiom --table-type \"Taxon table\" --to-hdf5`;
	`biom subset-table -i $tablebiom -a sample -s $selsampleid -o $tableselbiom`;
	`biom convert -i $tableselbiom -o $tablesel --to-tsv`;
	##rm the temp files 
	##adding the group information to LEfSe
	die "$!\n" unless open(ADDMETA, "$tablesel");
	die "$!\n" unless open(LEFSE, ">$tablelefse");
		
	<ADDMETA>; ##shift the header #
	my $head = <ADDMETA>;chomp($head);
	my @head = split(/\t/, $head);
	my @cater = ();
	for(my $i = 1; $i <= $#head; $i++){
		if(exists $$sidg{$head[$i]}){
			push @cater, $$sidg{$head[$i]};
		}
	}
	my $catrow = join("\t", "Cater", @cater);
	
	print LEFSE "$head\n$catrow\n";
	print LEFSE <ADDMETA>;

	close ADDMETA;
	close LEFSE;
	#`rm  $tablebiom; rm $tableselbiom; $rm $tablesel;`;
}

sub fetech_samples_group{
	#This function processing meta data file to fectch a small subset of samples ids by category information	
	#column_lable:Group1:Group2
	#Meta data file
	#The OUTPUT of this function is a file with the selected Sample IDs and a hash with sampleid->group information 

	my ($meta, $vector, $sidfile,$sidgroupmap) = @_;
	
	my ($columnid, @group) = split(/\:/, $vector);
	#print "$columnid\n";
	my %grouphash = ();
	for my $k (@group){
		#put all groups info into hash
		#print "$k\n";
		$grouphash{$k} =1;
	}
	die "$!\n" unless open(META, "$meta");
	my $head = <META>;
	chomp($head);
	my @h = split("\t", $head);
	my $index = 0; 
	for(my $i = 0; $i<= $#h; $i++){
		if($h[$i] eq $columnid){
			$index = $i;
			last;
		}
	}
	#print "$index\n";
	die "$!\n" unless open(SAMPLE, ">$sidfile");
	while(<META>){
		chomp;
		my @tem = split /\t/;
		if(exists $grouphash{$tem[$index]}){
			##select this sample
			print SAMPLE "$tem[0]\n";
			${$sidgroupmap}{$tem[0]} = $tem[$index];
		}
	}
	close META;
	close SAMPLE;
}
