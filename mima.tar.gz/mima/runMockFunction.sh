indir=/srv/scratch/z3534482/examples/mock_output
outdir=$indir/func

cmd="python3 func_profiling.py -i $indir/QC_module/CleanReads -o $outdir -e x.chua@unsw.edu.au --function-profiler humann3 --walltime 12 --mem 64 --threads 20 --debug"

echo
echo
echo $cmd
exec $cmd
echo
echo
