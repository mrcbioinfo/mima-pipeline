rm -fr /srv/scratch/z3534482/examples/output/Function_profiling

cmd="python3 func_profiling.py -i /srv/scratch/z3534482/examples/output/QC_module/CleanReads -o /srv/scratch/z3534482/examples/output -e x.chua@unsw.edu.au --function-profiler humann3 --walltime 12 --mem 32 --threads 20 --debug"

echo
echo
echo $cmd
exec $cmd
echo
echo
