#!/bin/bash

inputDir=.
outputDir=.

echo "Merging gene families ...\n"
echo "humann_join_tables -i $inputDir -o ${outputDir}/merge_humann3table_genefamilies.txt -s --file_name genefamilies.tsv"

