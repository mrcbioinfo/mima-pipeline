#!/usr/bin/perl
use strict;

die "perl $0 <report_list> <output_merge_reports>\n" unless(@ARGV == 2);
die  "$!\n" unless open(I, "$ARGV[0]");
die  "$!\n" unless open(T, ">$ARGV[1]");

my %taxa; #keep the taxa sample hash mapping  
my @samples = (); 
while(<I>){
	chomp;
	#file name as sample IDs 
	die "$!\n" unless open(TMP, "$_");
	my $name = $_;
	#$name =~ s/\.report.txt//g
	push @samples, $name;
	<TMP>;
	while(<TMP>){
		chomp;
		my @tem = split(/\t/, $_);
		$taxa{$tem[0]}{$name} = $tem[-1];
	}

	close(TMP);
}
close I;
my  $outheader = join("\t", "taxa", @samples);
print T "$outheader\n";
for my $tax (keys %taxa){
	print T "$tax";
	for(my $i=0; $i <= $#samples; $i++){
		if(exists $taxa{$tax}{$samples[$i]}){
			print T "\t$taxa{$tax}{$samples[$i]}"; 
		}else{
			#die "Error $tax $samples[$i]\n";
			print T "\t0";
		}
	}
	print T "\n";
}
