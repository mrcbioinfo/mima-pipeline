#!/bin/python3

import os
import pandas as pd
import logging

logging.getLogger('').setLevel(logging.DEBUG)


for rank in ('species','genus','family','order','class','phylum'):
  output_file=f"bracken_FT_{rank}"
  cmd=f"combine_bracken_outputs.py --files ../bracken/*_{rank} -o {output_file} > combine_bracken_{rank}.log"
  logging.debug(cmd)
  os.system(cmd)
  
  ## read generated output file and split into counts and relative abundances
  feat_table = pd.read_table(output_file)
  counts = feat_table.filter(regex='^name$|^taxonomy_id$|^taxonomy_lvl$|.*_num$')
  counts_file = f"{output_file}_counts"
  counts.to_csv(counts_file, sep="\t")
  logging.info(f"Writing: {counts_file}")

  rel_abund = feat_table.filter(regex='^name$|^taxonomy_id$|^taxonomy_lvl$|.*_frac$')
  relabund_file = f"{output_file}_relAbund"
  rel_abund.to_csv(relabund_file, sep="\t")
  logging.info(f"Writing: {relabund_file}")
