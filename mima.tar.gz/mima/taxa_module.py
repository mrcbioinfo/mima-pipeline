"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Taxonomy Profiling module

This is part of the MRC Metagenomics pipeline. This is the taxonomy profiling 
module that generates PBS scripts for processing multiple samples in a study. 

This module has the following profiling modes:

1. Metaphlan2
2. Metaphlan3
3. KrakenUniq
4. IGGsearch
5. Samtools/1.

OUTPUT: 1 PBS script per sample file

The pipeline is suitable for metagenomic analyses where samples are processed by
shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import os
import glob
import logging
import re
import shutil

from sys import argv


def get_kraken2_command(outdir):
    logging.info("Create required subdirectories...")

    subdir_kraken2=f"{outdir}kraken2"
    subdir_bracken=f"{outdir}bracken"

    logging.debug(f"Create {subdir_kraken2}")
    os.mkdir(subdir_kraken2)

    logging.debug(f"Create {subdir_bracken}")
    os.mkdir(subdir_bracken)

    generate_bracken_table(outdir)

    return("""## taxonomy profile using Kraken2
kraken2 --db {ref_path} --threads {threads} \
--report kraken2/{base_filename}.kraken2.report \
--paired {input_dir}{base_filename}{fwd_suffix} {input_dir}{base_filename}{rev_suffix} \
--output kraken2/{base_filename}.kraken2.output

## Intermediate step to fix missing 'root' annotation from our GTDB-kraken2 database
cp kraken2/{base_filename}.kraken2.report kraken2/{base_filename}.k2.report
sed -i 's/\\(C\\t1\\t$\\)/\\1root/1' kraken2/{base_filename}.k2.report


## Estimate abundance using Braken
bracken -d {ref_path} -i kraken2/{base_filename}.k2.report -o bracken/{base_filename}_phylum -r 150 -l P -t 1000
bracken -d {ref_path} -i kraken2/{base_filename}.k2.report -o bracken/{base_filename}_class -r 150 -l C -t 1000
bracken -d {ref_path} -i kraken2/{base_filename}.k2.report -o bracken/{base_filename}_order -r 150 -l O -t 1000
bracken -d {ref_path} -i kraken2/{base_filename}.k2.report -o bracken/{base_filename}_family -r 150 -l F -t 1000
bracken -d {ref_path} -i kraken2/{base_filename}.k2.report -o bracken/{base_filename}_genus -r 150 -l G -t 1000
bracken -d {ref_path} -i kraken2/{base_filename}.k2.report -o bracken/{base_filename}_species -r 150 -l S -t 1000

## move bracken reports to bracken directory
mv kraken2/{base_filename}.k2_bracken_*.report bracken/

rm kraken2/{base_filename}.k2.report
""")


def generate_bracken_table(outdir):
   """
   This function creates the 'featureTables' sub-directory in {outdir}
   and copies the 'generate_bracken_feature_table.py' python script.
  
   NOTE: the script does assume that Bracken is installed via conda as
         it uses the combine_bracken_output.py from Bracken
   """
   output_path=f"{outdir}featureTables"
   logging.debug(f"Create: {output_path}")
   os.mkdir(output_path)
   shutil.copyfile("utils/generate_bracken_feature_table.py", f"{output_path}/generate_bracken_feature_table.py")



# %% Define parameters
parser = argparse.ArgumentParser(description='Taxonomy profiling module part of the MRC Metagenomics pipeline',
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
taxArgs = parser.add_argument_group("[2] Taxonomy profile settings")
pbsArgs = parser.add_argument_group("[3] PBS settings")
optionalArgs = parser.add_argument_group("[4] Optional arguments")


## Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                     required=True,
                     help='path to input directory of cleaned sequences (e.g. QC_module/CleanReads)')
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')
requiredArgs.add_argument('-e', '--email',
                     required=True,
                     help='PBS setting - email address')
        
## Taxonomy profiler
taxArgs.add_argument('--taxon-profiler',
                     choices=['kraken2','metaphlan3','metaphlan2','krakenUniq','IGG'],
                     default='kraken2',
                     help="select which taxonomy profiler to use, default [default=%(default)s]")
taxArgs.add_argument('--fwd-suffix',
                     default='_clean_1.fastq.gz',
                     help='suffix of forward cleaned reads to search for in input_dir [default=%(default)s]')
taxArgs.add_argument('--rev-suffix',
                     default='_clean_2.fastq.gz',
                     help='suffix of reverse cleaned reads for PBS script [default=%(default)s]')
requiredArgs.add_argument('--reference-path',
                     required=True,
                     help="specify the path to the reference required for the selected taxonomic profiler")


# PBS settings
pbsArgs.add_argument('--mode',
                     required=False,
                     type=str,
                     default='single',
                     help='Mode to generate PBS scripts, currently supports single sample mode only [default=%(default)s]')
pbsArgs.add_argument('-w', '--walltime',
                     required=False,
                     type=int,
                     default=100,
                     help='walltime hours required for PBS job of MODE [default=%(default)s]')
pbsArgs.add_argument('-M', '--mem',
                     required=False,
                     type=int,
                     default=300,
                     help='memory (GB) required for PBS job of MODE [default=%(default)s]')
pbsArgs.add_argument('-t', '--threads',
                     type=int,
                     default=18,
                     help='number of threads for PBS job of MODE [default=%(default)s]')

## Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this help message and exit')
## TODO: other file types
optionalArgs.add_argument('-f','--file-type',
                          required=False,
                          type=str,
                          default="fastq",
                          help='input file type: [default=%(default)s]')
optionalArgs.add_argument('--verbose',
                          action='store_true',
                          default=False,
                          help="turn on will return verbose messages")
optionalArgs.add_argument('--debug',
                          action='store_true',
                          default=False,
                          help="turn on will return debugging message")


# %% entry point

if __name__ == '__main__':
    if len(argv) == 1:
        parser.print_help()
        exit()
    
    args = parser.parse_args()
    print("\n\n--- START ---")
    print(args)

    # set up logger, TODO: split levels later
    logging.getLogger('').setLevel(logging.WARNING)
    if (args.verbose):
       logging.getLogger('').setLevel(logging.INFO)
    
    if (args.debug):
       logging.getLogger('').setLevel(logging.DEBUG)

    
    # %% Check directoy paths, ensure ends with /
    # TODO: because introduce the QC_module output directory need another level
    input_dir = args.input_dir
    if not input_dir.endswith("/"):
        input_dir += '/'
    
    if not os.path.isdir(input_dir):
        logging.error("Input directory does not exist: %s", input_dir)
        exit()
    
    output_dir = args.output_dir
    if not output_dir.endswith("/"):
        output_dir += '/'
    output_dir += "Taxonomy_profiling/"
    
    
    # %% Creates output directories
    logging.info("Setting up output directories ...")
    logging.debug(f"Create: {output_dir}")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
    
    # %% Taxa profiling commands
    
    ## FIXME: change to match-case require Python 3.10. Currently using dictionary as workaround
    TAXON_PROFILERS={'metaphlan2': "mkdir metaphlan2 \nmetaphlan2.py {input_dir}/{base_filename}_clean_1.fastq,{input_dir}/{base_filename}_clean_2.fastq --bowtie2out metaphlan2/{base_filename}_metlsagenome.bowtie2.bz2 --nproc {threads} --input_type {file_type} > metaphlan2/{base_filename}_metagenome.txt",
                'metaphlan3': "mkdir metaphlan3 \nmetaphlan {input_dir}{base_filename}_clean_1.fastq,{input_dir}{base_filename}_clean_2.fastq --bowtie2out metaphlan3/{base_filename}_metlsagenome.bowtie2.bz2  --nproc {threads} --input_type {file_type} -o metaphlan3/{base_filename}_metagenome.txt",
                'krakenUniq': "mkdir krakenUniq \nkrakenuniq --db /srv/scratch/mrcbio/db/KrakenUniqDB --threads {threads} --unclassified-out krakenUniq/{base_filename}.unclassified.fq --classified-out krakenUniq/{base_filename}.classified.fq --output krakenUniq/{base_filename}.output --preload --paired --report-file krakenUniq/{base_filename}.report {input_dir}/{base_filename}_clean_1.fastq {input_dir}/{base_filename}_clean_2.fastq",
                'kraken2': get_kraken2_command(output_dir),
                'IGG': "module load samtools/1.9\nmkdir IGG \nrun_iggsearch.py search --m1 {input_dir}/{base_filename}_clean_1.fastq --m2 {input_dir}/{base_filename}_clean_2.fastq  --outdir IGG/{base_filename} --threads {threads}"}
    
    logging.debug(f"Selected profiler: {args.taxon_profiler}")
    profiler_cmd = TAXON_PROFILERS[args.taxon_profiler]

    
    ## TODO: reuse common code with qc_module.py
   # PBS_HEADER = """#!/bin/bash
    #PBS -N {base_filename}_taxaAnnot
    #PBS -l ncpus={threads}
    #PBS -l walltime={walltime}:00:00
    #PBS -l mem={mem}GB
    #PBS -j oe
    #PBS -m ae
    #PBS -M {email}
    
   # cd {output_dir}
   # 
   # """
    
    PBS_HEADER = """#!/bin/bash

#PBS -N {base_filename}_taxaAnnot
#PBS -l ncpus={threads}
#PBS -l walltime={walltime}:00:00
#PBS -l mem={mem}GB
#PBS -j oe
#PBS -m ae
    
source ~/myconda

conda activate mima
cd {output_dir}
    
"""
    
    # %% Generate PBS scripts
    # define variables within functions for each function
    logging.info("Generating PBS scripts for [MODE=%s] samples", args.mode)
    
    # TODO: set fixed values for mode, setup single PBS for batch processing
    # and use PBS array jobs
    
    SUFFIX = args.fwd_suffix

    PBS_COMMAND = PBS_HEADER + profiler_cmd

    inputFiles=glob.glob(f'{input_dir}*{SUFFIX}')
    logging.debug(f"Searching path: {input_dir}*{SUFFIX} ...\n[found {len(inputFiles)} files]")
    for fn in inputFiles:
        basename = os.path.basename(fn)
        if basename.find(SUFFIX):
            prefix = re.sub(SUFFIX, "", basename)
            pbsFile = f'{output_dir}{prefix}.pbs'
            
            logging.debug("Generate: %s", pbsFile)
            with open(pbsFile, 'w+') as output_file:
                output_file.write(PBS_COMMAND.format(base_filename=prefix,
                                                       threads=args.threads,
                                                       walltime=args.walltime,
                                                       mem=args.mem,
                                                       email=args.email,
                                                       input_dir=input_dir,
                                                       output_dir=output_dir,
                                                       file_type=args.file_type,
                                                       ref_path=args.reference_path,
						       fwd_suffix=args.fwd_suffix,
						       rev_suffix=args.rev_suffix))


