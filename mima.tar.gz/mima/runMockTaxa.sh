inputDir=/srv/scratch/z3534482/examples/mock_output

cmd="python3 taxa_module.py -i ${inputDir}/QC_module/CleanReads -o ${inputDir} -e x.chua@unsw.edu.au --reference-path /srv/scratch/mrcbio/db/GTDB/GTDB_Kraken --taxon-profiler kraken2 --walltime 2 --mem 300 --threads 24 --debug"

echo
echo
echo $cmd
exec $cmd
echo
echo
