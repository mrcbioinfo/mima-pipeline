"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Quality Check module

This is part of the MRC Metagenomics pipeline. This is the quality checking module that generates
PBS scripts for processing multiple samples in a study. The script contains commands for the three
steps:

1. Dereplication of reads using clumpify from BBTools
2. Quality checking using Fastp
3. Decontamination by removing reads that map to Human genome using minimap2

The pipeline is suitable for metagenomic analyses where samples are processed by
shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import os
import pandas as pd
import logging
from sys import argv
from utils import pbs_utils

# %% Helper functions

# TODO: move functions

def is_gzipped(filename):
    """
    Check if input file is gzipped

    Parameters
    ----------
        filename: str
            input filepath

    Returns:
        boolean
    """

    if filename.endswith(".gz"):
        return True
    else:
        return False


def get_unzip_base_file_command(input_dir, filename_R1, filename_R2):
    """
    Function for files to be unzipped

    Parameters
    ----------
    input_dir : str
        Directory path where input files are stored and will be unzipped
    filename_R1 : str
        Name of foward FastQ file
    filename_R2 : str
        Name of reverse FastQ file

    Returns
    -------
        Function for unzipping file

    """
    unzip_function = f"""    
gunzip {input_dir}{filename_R1}
gunzip {input_dir}{filename_R2}
"""
    return unzip_function


def get_common_qc_command(input_dir, filename_R1, filename_R2, base_filename, 
                          subs, threads, #dupedist, 
                          ref, clean_dir, qc_dir):
    """

    Function to return the command strings for QC steps: 
        dereplication with clumpify
        fastp checking
        removing host DNA reads using minimap2

    Parameters
    ----------
    input_dir : str
        Directory path where input files are stored
    base_filename : str
        Base filename
    subs : int
        Subs for clumplify.sh from BBTools - (s) Maximum substitutions allowed between duplicates
    threads : int
        Number of threads to use for 
    dupedist : int
        Deduplication setting used in clumpify.sh from BBTools
    ref : str
        Path to reference sequence for host genome for decontamination
    clean_dir : str
        Directory path to save output after final decontamination step
    qc_dir : str
        Directory path to save output after QC step with Fastp

    Returns
    -------
        str: QC commands to put into PBS script
    """
    
    ## TODO: use gzipped version of input and output
    ## TODO: should not move the raw data

#clumpify.sh in1={input_dir}{base_filename}_R1_001.fastq in2={input_dir}{base_filename}_R2_001.fastq out={base_filename}_clumpify_1.fastq out2={base_filename}_clumpify_2.fastq dedupe subs={subs} threads={threads} dupedist={dupedist}
    common_qc_command = f"""unset _JAVA_OPTIONS

inDir={input_dir}
outDir={clean_dir}
qcDir={qc_dir}

## quality control
repair.sh in1=${{inDir}}{filename_R1} in2=${{inDir}}{filename_R2} \\
out={base_filename}_repaired1.fq.gz out2={base_filename}_repaired2.fq.gz outs={base_filename}_singletons.fq.gz

clumpify.sh in1={base_filename}_repaired1.fq.gz in2={base_filename}_repaired2.fq.gz \\
out={base_filename}_clumpify_1.fq.gz out2={base_filename}_clumpify_2.fq.gz \\
dedupe subs={subs} threads={threads}

fastp -i {base_filename}_clumpify_1.fq.gz -I {base_filename}_clumpify_2.fq.gz \\
-o {base_filename}_qc_1.fq.gz -O {base_filename}_qc_2.fq.gz \\
-h ${{qcDir}}{base_filename}.outreport.html \\
-j ${{qcDir}}{base_filename}.json -p

## decontamination remove reads mapping to host genome
minimap2 -c {ref} {base_filename}_qc_1.fq.gz {base_filename}_qc_2.fq.gz  > {base_filename}_out_mapping.paf

awk '{{print $1}}' {base_filename}_out_mapping.paf > {base_filename}_out_mapping.txt

filterbyname.sh in1={base_filename}_qc_1.fq.gz in2={base_filename}_qc_2.fq.gz \\
out1=${{outDir}}{base_filename}_clean_1.fq.gz out2=${{outDir}}{base_filename}_clean_2.fq.gz \\
names={base_filename}_out_mapping.txt ow=t

## delete intermediate files
rm {base_filename}_repaired1.fq.gz
rm {base_filename}_repaired2.fq.gz
rm {base_filename}_clumpify_1.fq.gz
rm {base_filename}_clumpify_2.fq.gz
rm {base_filename}_out_mapping.paf
rm {base_filename}_out_mapping.txt
rm {base_filename}_qc_1.fq.gz
rm {base_filename}_qc_2.fq.gz
"""
    return common_qc_command


# %% Define parameters
parser = argparse.ArgumentParser(description="Quality checking module part of the MRC Metagenomics pipeline",
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
qcArgs = parser.add_argument_group("[2] QC settings")
pbsArgs = parser.add_argument_group("[3] PBS settings")
optionalArgs = parser.add_argument_group("[4] Optional arguments")


# Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                     required=True,
                     help='path to input directory of raw sequences (e.g., fastQ)')
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')
requiredArgs.add_argument('-m', '--manifest',
                     required=True,
                     help="""path to manifest file in .csv format. The header line
is case sensitive, and must follow the following format with no spaces between commas.
    
Sample_ID,FileID_R1,FileID_R2
""")

# QC processing settings
## FIXME: removed dupedist option because it failed in the test data with PRJEB13835
#qcArgs.add_argument('-d', '--dupedist',
#                    required=False,
#                    default=12000,
#                    type=int,
#                    help="""Max distance to consider for optical duplicates. Setting 
#used in clumpify.sh from BBTools. [default=%(default)s]
#Higher removes more duplicates but is more likely to remove 
#PCR rather than optical duplicates. This is platform-specific,
#recommendations:
#                       NextSeq      40  (and spany=t)
#                       HiSeq 1T     40
#                       HiSeq 2500   40
#                       HiSeq 3k/4k  2500
#                       Novaseq      12000
#                    """)
qcArgs.add_argument('-s', '--subs',
                    required=False,
                    type=int,
                    default=0,
                    help='Maximum number of substitutions allowed between duplicates used for clumpify.sh from BBTools')
qcArgs.add_argument('-r', '--ref',
                    required=False,
                    default="/srv/scratch/mrcbio/humangenome/GRCh38_latest_genomic.fna",
                    help='file path to reference host genome')

pbs_utils.add_pbs_parameters(requiredArgs, pbsArgs, default_mem=64, default_walltime=2, default_threads=8) 

## additional PBS settings
pbsArgs.add_argument('--num-pbs-jobs', 
                     required=False,
                     type=int,
                     default=4,
                     help='Number of PBS jobs where the number of samples processed will be equally distributed amongst the number of jobs [default=%(default)s]')


# Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this help message and exit')
optionalArgs.add_argument('--verbose',
                          action='store_true',
                          default=False,
                          help="turn on will return verbose meessages")
optionalArgs.add_argument('--debug',
                          action='store_true',
                          default=False,
                          help="turn on will return debugging messages")


# %% main entry
if __name__ == '__main__':
    if len(argv) == 1:
        parser.print_help()
        exit(0)
    args = parser.parse_args()

    if args.mode == 'singularity':
        if args.pbs_config is None:
            print("--mode singularity enabled, need to provide --pbs-config file with PBS headers and Singularity settings")
            exit(1)
    
    # %% Parse input
    manifest = args.manifest
    df = pd.read_csv(manifest, skipinitialspace=True,
                     converters={'Sample_ID':str.strip, 
                                 'FileID_R1':str.strip,
                                 'FileID_R2':str.strip})
    file_manifest = df.to_dict('records')
    
    logging.getLogger('').setLevel(logging.WARNING)
    if (args.verbose):
        logging.getLogger('').setLevel(logging.INFO)
    
    if (args.debug):
        logging.getLogger('').setLevel(logging.DEBUG)
    
    
    
    
    
    # %% Check directory paths, ensure ends with /
    # TODO: should check that input_dir is absolute path
    input_dir = args.input_dir
    if not input_dir.endswith("/"):
        input_dir += '/'
    
    output_dir = args.output_dir
    if not output_dir.endswith("/"):
        output_dir += '/'
    
    # output will be in 'QC_module' directory
    output_dir += "QC_module/"    
    
    # %% Creates output directories
    logging.info("Setting up output directories ...")
    logging.debug(f"Create: {output_dir}")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
    cleanreads_dir = "CleanReads"
    clean_path = os.path.join(output_dir, cleanreads_dir)
    os.makedirs(clean_path, exist_ok=True)
    logging.info(f"Created directory [{clean_path}]")
    
    clean_dir = clean_path
    if not clean_dir.endswith("/"):
        clean_dir += '/'
    
    ## store FastP output
    qcreport_dir = "QCReport"
    qcr_path = os.path.join(output_dir, qcreport_dir)
    os.makedirs(qcr_path, exist_ok=True)
    logging.info(f"Created directory [{qcr_path}]")
    
    qc_dir = qcr_path
    if not qc_dir.endswith("/"):
        qc_dir += '/'
 
    ## TODO: should not touch the users input data   
    #rawreads_dir = "RawReads"
    #rawreads_path = os.path.join(output_dir, rawreads_dir)
    #os.mkdir(rawreads_path)
    #logging.info("Created directory [%s]", rawreads_path)
    #raw_dir = rawreads_path
    #if not raw_dir.endswith("/"):
    #    raw_dir += '/'


    # %% Generate PBS scripts
    # define variables within functions for each function
    logging.info("Generating PBS scripts for [MODE=%s] samples", args.mode)
    
    # TODO: set fixed values for mode, setup single PBS for batch processing
    # and use PBS array jobs
    num_samples_per_job = int(len(file_manifest)/args.num_pbs_jobs)
    if (num_samples_per_job * args.num_pbs_jobs < len(file_manifest)):
        logging.debug("Adding 1 to num_samples_per_job")
        num_samples_per_job += 1
    sample_jobs=[file_manifest[i:i + num_samples_per_job] for i in range(0, len(file_manifest), num_samples_per_job)]

    for ix, group in enumerate(sample_jobs):
        pbs_script = f'{output_dir}qcModule_{ix}.pbs'
        logging.debug("Writing: %s", pbs_script)
        with open(pbs_script, 'w+') as out_pbs:
            if args.mode == 'singularity':
                out_pbs.write(pbs_utils.get_pbs_settings(args.pbs_config, output_dir))
            else:
                out_pbs.write(pbs_utils.get_pbs_header(f'QC_module_{ix}',
                                                        args.threads,
                                                        args.walltime,
                                                        args.mem,
                                                        args.email,
                                                        output_dir))

            for ID in group:
                commands = get_common_qc_command(input_dir,
                                                ID["FileID_R1"],
                                                ID["FileID_R2"],
                                                ID["Sample_ID"],
                                                args.subs,
                                                args.threads,
                                                args.ref,
                                                clean_dir,
                                                qc_dir)
            
                script_file = f'{output_dir}{ID["Sample_ID"]}.sh'
                logging.debug("Writing: %s", script_file)
                with open(script_file, 'w+') as output_file:
                    output_file.write(commands)

                if args.mode == 'singularity':
                    out_pbs.write(f'singularity exec ${{IMAGE_DIR}} bash {script_file} > {ID["Sample_ID"]}_qc_module.log 2>&1\n')
                else:
                    out_pbs.write(f'bash {script_file} > {ID["Sample_ID"]}_qc_module.log 2>&1\n')
