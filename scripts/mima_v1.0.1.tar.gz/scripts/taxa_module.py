"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Taxonomy Profiling module

This is part of the MRC Metagenomics pipeline. This is the taxonomy profiling 
module that generates PBS scripts for processing multiple samples in a study. 

This module has the following profiling modes:

1. Metaphlan2
2. Metaphlan3
3. KrakenUniq
4. IGGsearch
5. Samtools/1.

OUTPUT: 1 PBS script per sample file

The pipeline is suitable for metagenomic analyses where samples are processed by
shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

#%% setup
import argparse
import os
import glob
import logging
import re
import shutil
from utils import pbs_utils
from sys import argv


def get_kraken2_command(outdir):
    logging.info("Create required subdirectories...")

    subdir_kraken2=f"{outdir}kraken2"
    subdir_bracken=f"{outdir}bracken"

    logging.debug(f"Create {subdir_kraken2}")
    os.makedirs(subdir_kraken2, exist_ok=True)

    logging.debug(f"Create {subdir_bracken}")
    os.makedirs(subdir_bracken, exist_ok=True)

    generate_bracken_table(outdir)

    return("""input_dir={input_dir}
outdir_kraken2={output_dir}kraken2
outdir_bracken={output_dir}bracken

## taxonomy profile using Kraken2
kraken2 --db {ref_path} --threads {threads} \\
--report ${{outdir_kraken2}}/{base_filename}.kraken2.report \\
--paired ${{input_dir}}{base_filename}{fwd_suffix} ${{input_dir}}{base_filename}{rev_suffix} \\
--output ${{outdir_kraken2}}/{base_filename}.kraken2.output


## Estimate abundance using Braken
bracken -d {ref_path} -i ${{outdir_kraken2}}/{base_filename}.kraken2.report -o ${{outdir_bracken}}/{base_filename}_phylum -r {read_length} -l P -t {threshold} > {base_filename}_bracken.log 2>&1
bracken -d {ref_path} -i ${{outdir_kraken2}}/{base_filename}.kraken2.report -o ${{outdir_bracken}}/{base_filename}_class -r {read_length} -l C -t {threshold}  >> {base_filename}_bracken.log 2>&1
bracken -d {ref_path} -i ${{outdir_kraken2}}/{base_filename}.kraken2.report -o ${{outdir_bracken}}/{base_filename}_order -r {read_length} -l O -t {threshold}  >> {base_filename}_bracken.log 2>&1
bracken -d {ref_path} -i ${{outdir_kraken2}}/{base_filename}.kraken2.report -o ${{outdir_bracken}}/{base_filename}_family -r {read_length} -l F -t {threshold} >> {base_filename}_bracken.log 2>&1
bracken -d {ref_path} -i ${{outdir_kraken2}}/{base_filename}.kraken2.report -o ${{outdir_bracken}}/{base_filename}_genus -r {read_length} -l G -t {threshold}  >> {base_filename}_bracken.log 2>&1
bracken -d {ref_path} -i ${{outdir_kraken2}}/{base_filename}.kraken2.report -o ${{outdir_bracken}}/{base_filename}_species -r {read_length} -l S -t {threshold} >>{base_filename}_bracken.log 2>&1

## move bracken reports to bracken directory
mv ${{outdir_kraken2}}/{base_filename}.kraken2_bracken_*.report ${{outdir_bracken}}/
""")


def generate_bracken_table(outdir):
   """
   This function creates the 'featureTables' sub-directory in {outdir}
   and copies the 'generate_bracken_feature_table.py' python script.
  
   NOTE: the script does assume that Bracken is installed via conda as
         it uses the combine_bracken_output.py from Bracken
   """
   output_path=f"{outdir}featureTables"
   logging.debug(f"Create: {output_path}")
   os.makedirs(output_path, exist_ok=True)
   script_path = os.path.dirname(os.path.realpath(__file__))
   logging.debug(f"Script path: {script_path}")
   shutil.copyfile(f"{script_path}/utils/generate_bracken_feature_table.py", f"{output_path}/generate_bracken_feature_table.py")



# %% Define parameters
parser = argparse.ArgumentParser(description='Taxonomy profiling module part of the MRC Metagenomics pipeline',
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
taxArgs = parser.add_argument_group("[2] Taxonomy profile settings")
pbsArgs = parser.add_argument_group("[3] PBS settings")
optionalArgs = parser.add_argument_group("[4] Optional arguments")


## Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                     required=True,
                     help='path to input directory of cleaned sequences (e.g. QC_module/CleanReads)')
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')

        
## Taxonomy profiler
taxArgs.add_argument('--taxon-profiler',
                     choices=['kraken2'],
                     default='kraken2',
                     help="select which taxonomy profiler to use, default [default=%(default)s]")
taxArgs.add_argument('--fwd-suffix',
                     default='_clean_1.fq.gz',
                     help='suffix of forward cleaned reads to search for in input_dir [default=%(default)s]')
taxArgs.add_argument('--rev-suffix',
                     default='_clean_2.fq.gz',
                     help='suffix of reverse cleaned reads for PBS script [default=%(default)s]')
requiredArgs.add_argument('--reference-path',
                     required=True,
                     help="specify the path to the reference required for the selected taxonomic profiler")
requiredArgs.add_argument('--read-length',
                     type=int,
                     default=150,
                     help='read length for Bracken estimation of abundances')
requiredArgs.add_argument('--threshold',
                     type=int,
                     default=1000,
                     help='threshold [default=%(default)s] for Bracken estimation of abundances, species with reads below threshold are removed')

# PBS settings
pbs_utils.add_pbs_parameters(requiredArgs, pbsArgs, default_mem=320, default_walltime=48, default_threads=28)

## Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this help message and exit')
## TODO: other file types
optionalArgs.add_argument('-f','--file-type',
                          required=False,
                          type=str,
                          default="fastq",
                          help='input file type: [default=%(default)s]')
optionalArgs.add_argument('--verbose',
                          action='store_true',
                          default=False,
                          help="turn on will return verbose messages")
optionalArgs.add_argument('--debug',
                          action='store_true',
                          default=False,
                          help="turn on will return debugging message")


# %% entry point
if __name__ == '__main__':
    if len(argv) == 1:
        parser.print_help()
        exit()
    
    args = parser.parse_args()

    if args.mode == 'singularity':
        if args.pbs_config is None:
            print("--mode singularity enabled, need to provide --pbs-config file with PBS headers and Singularity settings")
            exit(1)
    

    # set up logger, TODO: split levels later
    logging.getLogger('').setLevel(logging.WARNING)
    if (args.verbose):
       logging.getLogger('').setLevel(logging.INFO)
    
    if (args.debug):
       logging.getLogger('').setLevel(logging.DEBUG)

    logging.debug("--- ARGS ---")
    parameters = vars(args)
    for k,v in parameters.items():
        logging.debug(f'{k}={v}')
    logging.debug("--- END ARGS ---")
    
    # %% Check directory paths, ensure ends with /
    # TODO: because introduce the QC_module output directory need another level
    input_dir = args.input_dir
    if not input_dir.endswith("/"):
        input_dir += '/'
    
    if not os.path.isdir(input_dir):
        logging.error("Input directory does not exist: %s", input_dir)
        exit()
    
    output_dir = args.output_dir
    if not output_dir.endswith("/"):
        output_dir += '/'
    output_dir += "Taxonomy_profiling/"
    
    
    # %% Creates output directories
    logging.info("Setting up output directories ...")
    logging.debug(f"Create: {output_dir}")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
    
    # %% Taxa profiling commands
    
    ## FIXME: change to match-case require Python 3.10. Currently using dictionary as workaround
    ## Currently only support kraken2 taxonomy profiler, have removed previous 
    ## profiler support (e.g., metaphlan2, IGG, krakenUniq etc)
    TAXON_PROFILERS={'kraken2': get_kraken2_command(output_dir)}
    
    logging.debug(f"Selected profiler: {args.taxon_profiler}")
    profiler_cmd = TAXON_PROFILERS[args.taxon_profiler]

    SUFFIX = args.fwd_suffix

    ## write a bash script for each sample file
    inputFiles=glob.glob(f'{input_dir}*{SUFFIX}')
    logging.debug(f"Searching path: {input_dir}*{SUFFIX} ...\n[found {len(inputFiles)} files]")
    SCRIPTS = []
    for fn in inputFiles:
        basename = os.path.basename(fn)
        if basename.find(SUFFIX):
            prefix = re.sub(SUFFIX, "", basename)
            scriptFile = f'{output_dir}{prefix}.sh'
            SCRIPTS.append(f'bash {scriptFile}')
            
            logging.debug("Generate: %s", scriptFile)
            with open(scriptFile, 'w+') as output_file:
                output_file.write(profiler_cmd.format(base_filename=prefix,
                                                       input_dir=input_dir,
                                                       output_dir=output_dir,
                                                       threads=args.threads,
                                                       file_type=args.file_type,
                                                       ref_path=args.reference_path,
                        						       fwd_suffix=args.fwd_suffix,
						                               rev_suffix=args.rev_suffix,
                                                       read_length=args.read_length,
                                                       threshold=args.threshold))

    # %% Generate PBS scripts
    # define variables within functions for each function
    logging.info("Generating PBS scripts for [MODE=%s] samples", args.mode)
    
    # TODO: set fixed values for mode, setup single PBS for batch processing
    # and use PBS array jobs
    ## TODO: reuse common code with qc_module.py
    
    ## create a single PBS job that calls the individual sample bash scripts
    pbsFile = f'{output_dir}/run_taxa_profiling.pbs'
    with open(pbsFile, 'w+') as output:
        if args.mode == 'singularity':
            output.write(pbs_utils.get_pbs_settings(args.pbs_config, output_dir))
            SCRIPTS = ["singularity exec ${IMAGE_DIR} " + sub for sub in SCRIPTS]
        else:
            output.write(pbs_utils.get_pbs_header('taxaAnnot',
                                                args.threads,
                                                args.walltime,
                                                args.mem,
                                                args.email,
                                                output_dir))
        
        output.write("\n".join(SCRIPTS) + '\n')
