################################################################################
#
# Copyright (c) 2020-2022, USNW MRC Bioinformatics team.
# 
# Visualisation module
# 
# This is part of the MRC Metagenomics pipeline. This is the visualisation
# module that generates alpha-diversity and beta-diversity visualisations. Plots
# are generated using R scripts.
# 
# The pipeline is suitable for metagenomic analyses where samples are processed by
# shotgun sequencing using paired-end libraries.
# 
# Documentation and Tutorials is located at [TODO: add URL]
#
################################################################################

## setup ----
library(argparse, quietly=T)
library(futile.logger, quietly=T)
library(funrar, quietly=T)
library(data.table, quietly=T)
suppressMessages(library(vegan, quietly=T))
library(ggplot2, quietly=T)
suppressMessages(library(reshape2, quietly=T))
library(ggpubr, quietly=T)
suppressMessages(library(dplyr, quietly=T))
suppressMessages(library(ape, quietly=T))
library(tibble, quietly=T)
library(ggfortify, quietly=T)
library(otuSummary, quietly=T)
library(pairwiseAdonis, quietly=T)

## find location of script, not necessarily run from this path
## FIXME: need more robust solution
script.args <- R.utils::commandArgs(trailingOnly=F, asValues=T)
script.dir <- dirname(script.args$file)

source(file.path(script.dir, "beta-diversity.R"))
source(file.path(script.dir, "alpha-diversity.R"))

## colour scheme
## TODO: move to ini file
mrccolors<- c("#000000","#fbb040","#be1e2d","#39b54a","#ffe600","#ee2a7b", "#00aeef", "#662d91")
col <- c("#B2DFEE","#FFEBCD","#6E8B3D","#87CEFA","#FF6A6A","#377EB8","#E41A1C","#EE9A49","#EED2EE","#EEEE00","#00E5EE","#EED8AE","#EE4A8C","#00EE76","#EE5C42","#5CACEE","#8B5A2B","#CD853F","#CD85CD","#CDCD00","#00C5CD","#CD8A96","#CD3278","#00CD66","#E41A1C","#4F94CD","#BC41A4","#CD4F39","#FFED6F","#CCEBC5","#BC80BD","#FCCDE5","#FDB462","#FB8072","#BEBADA","#377eb8","#4daf4a","#8DD3C7","#FFFFB3","#B3DE69","#80B1D3","#000000","#fbb040","#be1e2d","#39b54a","#ffe600","#ee2a7b", "#00aeef", "#662d91")
mrccolors <- rev(col)


## define arguments ----
parser <- ArgumentParser()
parser$add_argument('--working-directory', 
                    required=TRUE, 
                    help='Working directory to use during the execution of the script')

parser$add_argument('--feature-meta-table', 
                    required=TRUE, 
                    help='Path to taxonomy table file')

parser$add_argument('--num-meta-columns',  
                    required=TRUE, 
                    help='Number of metadata columns in the input table')

parser$add_argument('--ini-file', 
                    required=F, 
                    default=file.path(script.dir, 'figures.ini'),
                    help="Path to figures.ini configuration file, if not provided, will use the default MIMA ini file")

parser$add_argument('--plot-insignificant',
                    required=F,
                    action="store_true",
                    default=F,
                    help="Turn on to generate plots for insignificant comparisons")

parser$add_argument('--debug',
                    required=F,
                    action="store_true",
                    default=F,
                    help="Turns on debugging messages")

## get arguments ----
args <- parser$parse_args()

if (args$debug) {
   invisible(flog.threshold(DEBUG))
   #invisible(flog.appender(appender.tee(sprintf("visualisation.%s.log", format(Sys.time(), "%Y%m%d_%H%M%S")))))
}

## setup directories ----
flog.info("Parsing input...")
working_dir <- args$working_directory
tax_table <- args$feature_meta_table
num_meta_cols <- args$num_meta_columns
flog.debug("Reading: %s", basename(args$ini_file))
config <- ini::read.ini(args$ini_file)
config <- rapply(config, type.convert, as.is=T, how='list')

flog.debug("   working_dir= %s", working_dir)
flog.debug("     tax_table= %s", tax_table)
flog.debug(" num_meta_cols= %s", num_meta_cols)
flog.debug("ini parameters= %d settings", length(config))


## load data with metadata column ----
## TODO: try not to change working directory
flog.debug("Set working directory: %s", basename(working_dir))
setwd(dir=working_dir)
output_dir = working_dir

flog.debug("Loading feature table: %s", tax_table)
otu_m <- read.table(tax_table, header = T,row.names = 1,sep = "\t",quote="",comment.char="")
flog.debug("Num rows: %d", nrow(otu_m))
flog.debug("Num cols: %d", ncol(otu_m))


flog.debug("Extract metadata...")
meta <- data.frame(otu_m[,c(1:num_meta_cols), drop=FALSE])
flog.debug("Num rows: %d", nrow(meta))
flog.debug("Num cols: %d", nrow(meta))


remove_zeros <- function(x){
  if(is.numeric(x)){
    sum(x) > 0
  } else {
    TRUE
  }
}

flog.debug("Removing complete zeros ...")
otu_m <- otu_m[,sapply(otu_m, remove_zeros)]
flog.debug("Num rows: %d", nrow(meta))
flog.debug("Num cols: %d", nrow(meta))


data <- otu_m[,c((ncol(meta)+1):ncol(otu_m))]
sample.totals <- round(rowSums(data))
if (all(sample.totals == 1) || all(sample.totals == 100)) {
  ## table is already relative counts or proportions, so why do we need to
  ## repeat? 
  ## otuSummary::alphaDiversity() function works with counts so for shotgun
  ## metagenomics data which are generally in relative abundance we need to
  ## make them discrete counts. Will multiply by 1e6.
  count.matrix <- as.data.frame(data*1e6)
  relabund.matrix <- data
} else {
  relabund.matrix <- as.data.frame(make_relative(as.matrix(data)))
  count.matrix <- data
}
rm(data, sample.totals)



# Generate output directories ----
alpha_output_dir <- paste0(working_dir, "_alpha/")
beta_output_dir  <- paste0(working_dir, "_beta/")
diff_abundance_output_dir <- paste0(working_dir, "_diff-abundance/")
flog.info("Creating output subdirectories ...\n\t%s\n\t%s\n\t%sin [%s]",
          basename(alpha_output_dir),
          basename(beta_output_dir),
          basename(diff_abundance_output_dir),
          working_dir)

dir.create(alpha_output_dir, showWarnings = FALSE)
dir.create(beta_output_dir, showWarnings = FALSE)
dir.create(diff_abundance_output_dir, showWarnings = FALSE)

outFile <- sprintf('%s/otu_matrix.txt', working_dir)
flog.debug("Writing: %s", outFile)
write.table(otu_m, outFile, sep = "\t")


## =============================================================================
##
## Execute beta diversity ----
##

generate_beta_diversity(colnames(meta), relabund.matrix, otu_m, beta_output_dir, config)

## Debugging use
# treatment_groups <- colnames(meta)
# microbial_variables <- relabund.matrix
# meta_taxa <- otu_m
# output_dir <- beta_output_dir


## =============================================================================
##
## Execute alpha diversity ----
##

## FIXME: otuSummary requires counts, passing relative counts throws error
generate_alpha_diversity(count.matrix, meta, alpha_output_dir, config, plot_inSig=TRUE)

## Debugging use
# microbial_variables <- count.matrix
# metadata <- meta
# output_dir <- alpha_output_dir


## =============================================================================
##
## Execute differential abundance ----
##

generate_variance_stats(relabund.matrix, meta, diff_abundance_output_dir,
                        config = config, 
                        plot_inSig =args$plot_insignificant,
                        gen_wilcox_plots=TRUE)

## Debugging use
# data_matrix <- relabund.matrix
# metadata <- meta
# output_dir <- diff_abundance_output_dir
# gen_wilcox_plots <- T
# colnames(metadata)
# treatment_group <- colnames(metadata)

