# Copyright 2020
# Author: Emily Mc Govern
# Email: emily.mcgovern@unsw.edu.au

library(ggpubr)
library(dunn.test)
library(EnhancedVolcano)

kruskal_wallis_test <- function(dta, output_dir){
  flog.debug("Variance-stats > Performing Kruskal Wallis test ...")
  treatment_group = colnames(dta)[1]
  
  ## filter features based on min prevalence
  min_samples <- nrow(dta)*0
  dta <- dta[,c(TRUE,colSums(dta[,c(2:ncol(dta))] > 0) > min_samples)]
  
  outFile <- paste0(output_dir, treatment_group, "_", "filter_table.txt")
  flog.debug("Variance-stats > Kruskal Wallis > writing: %s", basename(outFile))
  write.table(dta, outFile, sep="\t",quote = F,row.names=TRUE,col.names=NA)
  
  
  KW <- lapply(dta[,c(2:ncol(dta))], function(x) kruskal.test(x~dta[,c(treatment_group)]))
  kw_pval <-sapply(KW, function(x) x[["p.value"]][[1]][1])
  FDR <- p.adjust(kw_pval, "fdr")
  pval_fdr <-cbind(kw_pval,FDR)
  mn <- data.frame(t(data.frame(aggregate(. ~ get(treatment_group),data=dta,FUN=mean),row.names = 1)))
  kruskal_table <- merge(pval_fdr,mn,by="row.names")
  kruskal_table <- kruskal_table[order(kruskal_table$kw_pval),]
  
  outFile <- paste0(output_dir, treatment_group, "_" , "kw_stat_summary.txt")
  flog.debug("Variance-stats > Kruskal Wallis > writing: %s", basename(outFile))
  write.table(kruskal_table, outFile, quote = F, sep = "\t")
  return(kruskal_table)
}


dunn_test <- function(dta, output_dir) {
  flog.debug("Variance-stats > Performing Dunn's test ...")
  treatment_group = colnames(dta)[1]
  if (length(levels(dta[,c(treatment_group)]))>2){
    # list taxa in otu table
    tCol = colnames(dta[,c(2:ncol(dta))])
    succeedDunnTest = list()
    #loop to run dunn test
    out <- matrix(NA, nrow=length(tCol), ncol=length(combn(levels(as.factor(dta[,c(treatment_group)])),2,list)))
    i <- 1
    for (t in tCol){ ## overwrites errors and continues loop
      tryCatch(
        {
          output = dunn.test(dta[,t],as.factor(dta[,c(treatment_group)]), method = "BH", table =TRUE)
          out[i,] <- output$P.adjusted # prints matrix for pvalues for all treatment comparisons (i)
          colnames(out) <- output$comparisons # column names are comparisons
          succeedDunnTest[[i]] <- t
          i <- i + 1
        },
        error=function(cond) {
          flog.error("Variance-stats > Error processing %s", t)
          write(sprintf("Error processing %s", t), file = stderr())
        },
        warning=function(cond) {
        },
        finally={
        }
      )
    }
    out <- out[!apply(is.na(out),1,all),] # remove empty rows (NA) from failed runs
    rownames(out) <- succeedDunnTest # names rows with taxa names
    
    outFile <- paste0(output_dir, treatment_group, "_" , "pairwise_dunn_test.txt")
    flog.debug("Variance-stats > Dunn's test > writing: %s", basename(outFile))
    write.table(out, outFile, quote = F, sep = "\t")
  }
}



generate_wilcox_table  <- function(dta, pseudocount, controlgroup, output_dir){
  flog.debug("Variance-stats > Generating Wilcox table ...")
  
  treatment_group <- colnames(dta)[1]
  wilcox_table_output = paste(output_dir, "wilcox-pairwise/", sep = "")
  if (!dir.exists(wilcox_table_output)) {
    dir.create(wilcox_table_output)
  }
  
  if (length(levels(dta[,treatment_group]))==2){
    wil_p_mn = data.frame()
    g = levels(dta[,c(treatment_group)])
    
    wil = lapply(dta[, c(2:ncol(dta))], function(x)
      tryCatch({
        wilcox.test(x ~ dta[, c(treatment_group)], conf.int = TRUE)
      }, error = function(cond) {
        r <- wilcox.test(x ~ dta[, c(treatment_group)])
        r$estimate <- NA
        return(r)
      }))
    
    wil_pval = sapply(wil, function(x) x[["p.value"]][[1]][1])
    HodgesLehmann = sapply(wil, function(x) x[["estimate"]][[1]][1])
    wil_FDR = p.adjust(wil_pval, "fdr")
    # merge pvalue and fdr
    p_fdr = cbind(wil_pval,wil_FDR,HodgesLehmann)
    mn = data.frame(t(data.frame(aggregate(.~get(treatment_group), data=dta,FUN=mean),row.names = 1)))
    wil_p_mn = merge(p_fdr,mn,by="row.names")
    
    if (names(wil_p_mn)[length(names(wil_p_mn))-1] == controlgroup){
      wil_p_mn$d = wil_p_mn[,length(names(wil_p_mn))] - wil_p_mn[,length(names(wil_p_mn))-1]
      wil_p_mn$Log2FC = log2(wil_p_mn[,length(names(wil_p_mn))-1] / wil_p_mn[,length(names(wil_p_mn))-2])
      wil_p_mn$adjustedLog2FC = log2((wil_p_mn[,length(names(wil_p_mn))-2]+pseudocount) / (wil_p_mn[,length(names(wil_p_mn))-3]+pseudocount))
    } else if (names(wil_p_mn)[length(names(wil_p_mn))] == controlgroup){
      wil_p_mn$d = wil_p_mn[,length(names(wil_p_mn))-1] - wil_p_mn[,length(names(wil_p_mn))]
      wil_p_mn$Log2FC = log2(wil_p_mn[,length(names(wil_p_mn))-2] / wil_p_mn[,length(names(wil_p_mn))-1])
      wil_p_mn$adjustedLog2FC = log2((wil_p_mn[,length(names(wil_p_mn))-3]+pseudocount) / (wil_p_mn[,length(names(wil_p_mn))-2]+pseudocount))
    } else{
      warning("Warning message: log2 fold of change will be calculated by default direction")
      wil_p_mn$d = wil_p_mn[,length(names(wil_p_mn))] - wil_p_mn[,length(names(wil_p_mn))-1]
      wil_p_mn$Log2FC = log2(wil_p_mn[,length(names(wil_p_mn))-1] / wil_p_mn[,length(names(wil_p_mn))-2])
      wil_p_mn$adjustedLog2FC = log2((wil_p_mn[,length(names(wil_p_mn))-2]+pseudocount) / (wil_p_mn[,length(names(wil_p_mn))-3]+pseudocount))
    }
    
    ## order
    wil_p_mn = wil_p_mn[order(wil_p_mn$wil_pval),]
    
    ## correct the direction of HodgesLehmann
    if (sum(sign(wil_p_mn$HodgesLehmann*wil_p_mn$d),na.rm = T)<0){
      wil_p_mn$HodgesLehmann = wil_p_mn$HodgesLehmann*-1
    }
    
    ## directions
    wil_p_mn$HL_direction =  ifelse(sign(wil_p_mn$HodgesLehmann)>0,"Increase","Decrease")
    wil_p_mn$d_direction =  ifelse(sign(wil_p_mn$d)>0,"Increase","Decrease")
    # write.table(wil_p_mn, paste("./differential_abundance_analysis/", cols, "_" , ".wil.stat_summary.txt"), quote = F, sep = "\t", row.names=F)
    
    outFile <- paste0(wilcox_table_output, treatment_group, "_",  g[1], "_", g[2], ".wil.stat_summary.txt")
    flog.debug("Variance-stats > Wilcox table > writing: %s", basename(outFile))
    write.table(wil_p_mn, outFile, sep="\t",quote = F,row.names=F)#write table
    return(wil_p_mn)
  }
}


generate_wilcox_plots <- function(dta, wilcox_table, output_dir, config){
  flog.debug("Variance-stats > Plotting Wilcox volcano plots ...")
  
  treatment_group <- colnames(dta)[1]
  volcano_output <- paste0(output_dir, "volcano/")
  barplot_output <- paste0(output_dir, "barplot/")
  
  flog.debug("Variance-stats > Create subdirectories ...\n\t%s\n\t%s", 
             basename(volcano_output), 
             basename(barplot_output))
  dir.create(volcano_output, showWarnings = FALSE)
  dir.create(barplot_output, showWarnings = FALSE)
  
  g <- levels(dta[,c(treatment_group)])
  
  ## TODO: reduce the code and use loops for different y values
  p <- EnhancedVolcano(wilcox_table,
		   lab = wilcox_table$Row.names, 
		   x='d', 
		   y='wil_pval', 
		   pCutoff = 0.05, 
		   FCcutoff = 0, 
		   xlab = 'change of abundance',
		   pointSize=2,
		   colAlpha = .3,
		   labSize = 3,
		   col=c('black', 'grey50', 'purple', 'red2'),
		   legendPosition = 'bottom',
		   legendLabSize = 10) +
		   #col=c('black', 'black', 'red3', 'red3')) +
    theme(aspect.ratio=1,
          axis.title = element_text(face="bold", size=11),
          axis.title.x = element_text(margin=margin(t=3, unit='mm')),
          axis.title.y = element_text(margin=margin(r=3, unit='mm')),
          axis.text.x = element_text(size=10),
          axis.text.y = element_text(size=10),
          plot.caption = element_text(size=9))
  figFile <- paste0(volcano_output, g[1], "_", g[2], ".volcanoplot.d.p.", config$volcano.fig$ext)
  flog.debug("Variance-stats > Wilcox plots: %s", figFile)
  ggsave(p, filename=figFile, 
         width=config$volcano.fig$width, 
         height=config$volcano.fig$height, 
         unit=config$volcano.fig$units, 
         dpi=320)

  
  ## TODO: Volcano plot for ???
  p <- EnhancedVolcano(wilcox_table,
		   lab = wilcox_table$Row.names,
		   x = 'd',
		   y = 'wil_FDR',
		   pCutoff = 0.05,
		   FCcutoff = 0,
		   xlab = 'change of abundance',
		   ylab = '-Log10 adjusted P',
		   pointSize = 2,
		   colAlpha = .3,
		   labSize = 3,
		   col=c('black', 'black', 'red3', 'red3'),
		   legendPosition = 'bottom',
		   legendLabSize = 10) +
    theme(aspect.ratio=1)
  figFile <- paste0(volcano_output, treatment_group, g[1], "_", g[2], ".volcanoplot.d.FDR.", config$volcano.fig$ext)
  flog.debug("Variance-stats > Wilcox plots: %s", figFile)
  ggsave(p, filename=figFile, 
         width=config$volcano.fig$width, 
         height=config$volcano.fig$height, 
         unit=config$volcano.fig$units, 
         dpi=320)

  
  
  ## TODO: volcano plot ...
  p <- EnhancedVolcano(wilcox_table,
		   lab = wilcox_table$Row.names,
		   x = 'adjustedLog2FC',
		   y = 'wil_FDR',
		   pCutoff = 0.05,
		   FCcutoff = 1.0,
		   pointSize = 2,
		   colAlpha = .3,
		   labSize = 3,
		   ylab = '-Log10 adjusted P',
		   legendPosition = 'bottom',
		   legendLabSize = 10) +
    theme(aspect.ratio = 1)
  figFile <- paste0(volcano_output,treatment_group, g[1], "_", g[2], ".volcanoplot.Log2FC.FDR.", config$volcano.fig$ext)
  flog.debug("Variance-stats > Wilcox plots: %s", figFile)
  ggsave(p, filename=figFile, 
         width = config$volcano.fig$width,
         height = config$volcano.fig$height,
         units = config$volcano.fig$units,
         dpi = 320)
  
  

  ## TODO: volcano plot ...
  p <- EnhancedVolcano(wilcox_table,
		   lab = wilcox_table$Row.names,
		   x = 'adjustedLog2FC',
		   y = 'wil_pval',
		   pCutoff = 0.05,
		   FCcutoff = 1.0,
		   pointSize = 2,
		   colAlpha = .3,
		   labSize = 3,
		   legendPosition = 'bottom',
		   legendLabSize = 10) +
    theme(aspect.ratio = 1)

  figFile <- paste0(volcano_output, treatment_group, g[1], "_", g[2], "_volcanoplot_Log2FC_p.", config$volcano.fig$ext)
  flog.debug("Variance-stats > Wilcox plots: %s", figFile) 
  ggsave(p, filename=figFile,
         width = config$volcano.fig$width,
         height = config$volcano.fig$height,
         units = config$volcano.fig$units,
         dpi = 320)

  
  ####--------------------------------------------------------------------------
  ##
  
  ## Generate differential abundance bar plots using univariate analysis
  ## comparing two study groups
  
  ## TODO: 
  ##  - need to reduce code
  ##  - check what happens for more than two groups
  
  ## significant outcome after FDR adjustment
  p <- subset(wilcox_table, !is.na(HodgesLehmann) & wil_FDR<0.05)
  p$Row.names <- factor(p$Row.names,levels = p$Row.names[order(p$HodgesLehmann)])

  base.plt <- ggplot(p, aes(x=Row.names,y=HodgesLehmann,fill=HL_direction)) + 
    geom_bar(stat = "identity") + 
    scale_fill_manual(values=c("Decrease"="#33a02c","Increase"="#e31a1c")) +
    coord_flip() + 
    xlab("") + 
    ylab("Difference in location (Hodges-Lehmann estimator)") + 
    theme_classic()
  
  if (nrow(p) > 0) {
    figFile <- paste0(barplot_output,treatment_group, g[1], "_", g[2], "_barplot_FDR.", config$diffAbund.fig$ext)
    flog.debug("Variance-stats > Wilcox plots: %s", figFile)
    q <- base.plt %+% p
    ggsave(q, filename=figFile,
           width =config$diffAbund.fig$width,
           height=config$diffAbund.fig$height,
           unit = config$diffAbund.fig$units,
           dpi = 320)
  } else {
    flog.debug("Variance-stats > WIlcox plots: No significant results after FDR adj")
  }

  ## significant before FDR adjustment
  p <- subset(wilcox_table, !is.na(HodgesLehmann) & wil_pval<0.05)
  p$Row.names <- as.factor(p$Row.names)
  p$Row.names <- reorder(p$Row.names, p$HodgesLehmann)

  if (nrow(p) > 0) {  
    q <- base.plt %+% p
    figFile <- paste0(barplot_output,treatment_group, g[1], "_", g[2], "_barplot_p.", config$diffAbund.fig$ext)
    flog.debug("Variance-stats > Wilcox plots: %s", figFile)
    ggsave(q, filename=figFile,
           width = config$diffAbund.fig$width,
           height =config$diffAbund.fig$height,
           unit = config$diffAbund.fig$units,
           dpi = 320)
  } else {
    flog.debug("Variance-stats > Wilcox plots: %s No significant before FDR adj")
  }
}



generate_wilcox_boxplots <- function(kruskal_table, dta, output_dir, config, plot_inSig=FALSE){
  flog.debug("Variance-stats > Plotting Wilcox boxplots ...")
  
  treatment_group <- colnames(dta)[1]
  
  boxplot_dir <- paste0(output_dir, "boxplots/")
  boxplot_corrected_sig_dir <- paste0(boxplot_dir, "corrected_sig/")
  boxplot_uncorrected_sig <- paste0(boxplot_dir, "uncorrected_sig/")
  
  flog.debug("Variance-stats > Wilcox boxplot > Creating subdirectories ... \n\t%s\n\t%s",
             basename(boxplot_corrected_sig_dir),
             basename(boxplot_uncorrected_sig))
  dir.create(boxplot_corrected_sig_dir, recursive = T, showWarnings = FALSE)
  dir.create(boxplot_uncorrected_sig, recursive = T, showWarnings = FALSE)
  if (plot_inSig) {
    boxplot_non_sig <- paste0(boxplot_dir, "non_sig/")
    flog.debug("Variance-stats > Wilcox boxplot > Creating subdirectories ... \n\t%s",
               boxplot_non_sig)
    dir.create(boxplot_non_sig, recursive = T, showWarnings = FALSE)
  }
  
  ## TODO: allow significance (0.05) be a setting  
  sig <- subset(kruskal_table,kruskal_table$FDR < 0.05)
  sig_no_correction <- subset(kruskal_table,kruskal_table$kw_pval < 0.05)
  nonsig <- subset(kruskal_table,kruskal_table$kw_pval >= 0.05)
  flog.debug("Num adjusted significant results: %d", nrow(sig))
  flog.debug("Num unadj significant results: %d", nrow(sig_no_correction))
  flog.debug("Num insignificant results: %d", nrow(nonsig))

  comp <- combn(levels(dta[,treatment_group]),2,list)
  tCol <- colnames(dta)[-1]
  if (!plot_inSig) {
    tCol <- setdiff(tCol, nonsig$Row.names)
  }
  for (t in tCol){
    a <- strsplit(t, '.', fixed = T)

    if (t %in% sig$Row.names){
      outdirprefix <- paste0(boxplot_corrected_sig_dir, t)
    } else if (t %in% sig_no_correction$Row.names) {
      outdirprefix <- paste0(boxplot_uncorrected_sig, t)
    } else if (t %in% nonsig$Row.names) {
      outdirprefix <- paste0(boxplot_non_sig, t)
    }
    
    p <- ggboxplot(na.omit(dta), 
              x = treatment_group, 
              y = t, 
              size = .5,
              alpha = .3, 
              add='dotplot',
              add.params=list(alpha=.5, fill='grey50', color='grey50'),
              color = treatment_group, 
              fill = treatment_group,
              palette = tail(mrccolors, -22),
              font.label = list(size = 30),
              legend = "none") + 
      #labs(x="", y=a[[1]][length(a[[1]])]) +
      #rotate_x_text(angle = 45) + # Add horizontal line at base mean
      stat_compare_means(comparisons=comp, 
                         label="p.signif", 
                         label.y = max(dta[[t]]) * 1.01,
                         method="wilcox.test",
                         p.adjust.method="BH") +
      theme(aspect.ratio = 1, 
            axis.title = element_text(face="bold"),
            axis.title.x = element_text(size=config$alpha.boxplot.x.axis$title.size,
                                        margin=margin(t=3, unit='mm')),
            axis.title.y = element_text(size=config$alpha.boxplot.y.axis$title.size,
                                        margin=margin(r=3, unit='mm')),
            axis.text.x = element_text(size=config$alpha.boxplot.x.axis$text.size),
            axis.text.y = element_text(size=config$alpha.boxplot.y.axis$text.size),
            panel.grid.major.y = element_line(colour='grey85'))
    #stat_compare_means(method = "kruskal.test")        # Add global annova p-value
    
    
    figFile <- sprintf("%s_%s_dotplot.%s", outdirprefix, 
                                           treatment_group, 
                                           config$alpha.boxplot.fig$ext)
    flog.debug("Variance-stats > Wilcox boxplot: %s", basename(figFile))
    ggsave(p, filename=figFile, 
           width=config$alpha.boxplot.fig$width, 
           height=config$alpha.boxplot.fig$width, 
           units = config$alpha.boxplot.fig$units, 
           dpi = 320)
  }
}


generate_variance_stats <- function(data_matrix, metadata, output_dir, config, 
                                    plot_inSig=FALSE,
                                    gen_wilcox_plots=FALSE) {
  flog.debug("Variance statistics ...")
  
  for (treatment_group in colnames(metadata)) {
    flog.debug("Variance-stats > Study group: [%s]", treatment_group)
    metadata[metadata==""]  <- NA
    data_matrix_with_names <- rownames_to_column(data_matrix, var="Row.names")
    metadata_with_names <- rownames_to_column(metadata, var="Row.names")
    microbial_vars_one_treatment <- merge(metadata_with_names[,c("Row.names", treatment_group)], data_matrix_with_names, by="Row.names", all.x=TRUE)
    microbial_vars_one_treatment <- data.frame(microbial_vars_one_treatment, row.names = 1)
    
    ## TODO: allow user to specify which is the control group
    microbial_vars_one_treatment[[treatment_group]] <- as.factor(microbial_vars_one_treatment[[treatment_group]])

    ## Test for mean difference
    kruskal_table <- kruskal_wallis_test(microbial_vars_one_treatment, output_dir)
    dunn_test(microbial_vars_one_treatment, output_dir)

    comp <- combn(levels(microbial_vars_one_treatment[[treatment_group]]), 2, list)
    for (pair in comp){
      sub <- subset(microbial_vars_one_treatment, get(treatment_group) %in% pair)
      sub <- droplevels.data.frame(sub)

      ## TODO: reference group may not always have these labels
      control.grp <- grep("Control|control|CTRL", pair, value=T)
      if (!rlang::is_empty(control.grp) & length(control.grp)==1) {
        wilcox_table <- generate_wilcox_table(sub, 1, control.grp, output_dir)
      } else {
        wilcox_table <- generate_wilcox_table(sub, 1, pair[1], output_dir)
      }
      
      if (gen_wilcox_plots){
        ## XYC debugging
        #dta <- microbial_vars_one_treatment
        generate_wilcox_plots(microbial_vars_one_treatment, wilcox_table, 
                              output_dir, 
                              config)
      }
    }
    generate_wilcox_boxplots(kruskal_table, microbial_vars_one_treatment, 
                             output_dir, 
                             config,
                             plot_inSig)
  }
}
