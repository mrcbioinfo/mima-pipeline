"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Functional profiling module

This is part of the MRC Metagenomics pipeline. This is the functional 
profiling module that generates PBS scripts for processing multiple samples 
in a study. 

This module has the following profiling modes:

- Humann2
- Humann3

OUTPUT: 1 PBS script per sample file

The pipeline is suitable for metagenomic analyses where samples are processed 
by shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import os
import glob
import logging
import re

from sys import argv
from utils import pbs_utils
from utils.PathUtils import sanitise_directory_name


# %% Functional profiling commands
def get_humann2_command(input_dir, base_filename, pipeline_dir, threads):
    return f"""
# Merge fastq forward and backward reads
module load JULIA VERSION
julia {pipeline_dir}install.jl
julia {pipeline_dir}combine_fastq.jl {input_dir}{base_filename}_clean_1.fastq {input_dir}{base_filename}_clean_2.fastq {input_dir}{base_filename}_clean.fastq

# Execute HUMAnN2
mkdir -p $(base_filename)
humann2 --input {input_dir}{base_filename}_clean.fastq --output {base_filename} --threads {threads}
"""

## TODO: change to 'cat' command
def get_combine_command(input_dir, base_filename, fwd_suffix, rev_suffix, outdir):
    #return f"""julia combine_fastq.jl {input_dir}{base_filename}_clean_1.fastq {input_dir}{base_filename}_clean_2.fastq {outdir}/{base_filename}_combine.fastq"""
    return f"""cat {input_dir}{base_filename}{fwd_suffix} {input_dir}{base_filename}{rev_suffix} > {outdir}{base_filename}_combine.fq.gz"""


def get_humann3_command(mode, input_dir, base_filename, threads, 
                        fwd_suffix, rev_suffix, outdir,
                        nucleotide_database, protein_database, mpa3, metaphlan_database):   
    command = "# Execute HUMAnN3\n"
    command += get_combine_command(input_dir, base_filename, fwd_suffix, rev_suffix, outdir)
    if mode == 'singularity':
        command += f"""

outdir={outdir}
singularity exec ${{IMAGE_DIR}} humann -i ${{outdir}}{base_filename}_combine.fq.gz --threads {threads} \\
-o $outdir --memory-use maximum \\
--nucleotide-database {nucleotide_database} \\
--protein-database {protein_database} \\
--search-mode uniref90 \\
"""
    else:
        command += f"""

outdir={outdir}
humann -i ${{outdir}}{base_filename}_combine.fq.gz --threads {threads} \\
-o $outdir --memory-use maximum \\
--nucleotide-database {nucleotide_database} \\
--protein-database {protein_database} \\
--search-mode uniref90 \\
"""
    if mpa3:
        command += f'--metaphlan-options="--mpa3 --bowtie2db {metaphlan_database}"\n'
    else:
        command += f'--metaphlan-options="--bowtie2db {metaphlan_database}"\n'

    command += f"\nrm {outdir}{base_filename}_combine.fq.gz\n"
    return command


def generate_humann_feature_tables(func_output_dir, email, args):
    """
    Generates the script to combine all function profiling tables

    :param func_output_dir: directory that consists of the outputs from HUMAnN
    :param email: user email address for PBS script
    """

    feature_table_dir=f"{func_output_dir}featureTables"
    logging.debug(f"Create: {feature_table_dir}")
    os.makedirs(feature_table_dir, exist_ok=True)

    script_file=f"{feature_table_dir}/generate_func_feature_tables.sh"
    with open(script_file, 'w') as outfile:
       outfile.write(f"""
## Merge gene families
humann_join_tables -i {func_output_dir} -o {feature_table_dir}/merge_humann3table_genefamilies.txt -s --file_name genefamilies.tsv

humann_join_tables -i {func_output_dir} -o {feature_table_dir}/merge_humann3table_pathabundance.txt -s --file_name pathabundance.tsv

humann_join_tables -i {func_output_dir} -o {feature_table_dir}/merge_humann3table_pathcoverage.txt -s --file_name pathcoverage.tsv


## Normalise to CPM
humann_renorm_table -i {feature_table_dir}/merge_humann3table_genefamilies.txt -o {feature_table_dir}/merge_humann3table_genefamilies.cpm.txt

humann_renorm_table -i {feature_table_dir}/merge_humann3table_pathabundance.txt -o {feature_table_dir}/merge_humann3table_pathabundance.cmp.txt

humann_renorm_table -i {feature_table_dir}/merge_humann3table_pathcoverage.txt -o {feature_table_dir}/merge_humann3table_pathcoverage.cmp.txt


## Regroup gene families
humann_regroup_table -i {feature_table_dir}/merge_humann3table_genefamilies.cpm.txt -o {feature_table_dir}/merge_humann3table_genefamilies.cmp_uniref90_KO.txt -g uniref90_rxn -c {args.utility_database}/map_ko_uniref90.txt.gz 
""")
    

    ## output PBS script
    pbs_file=f"{feature_table_dir}/generate_func_feature_tables.pbs"
    logging.debug(f"Writing: {pbs_file}")
    with open(pbs_file, 'w') as outfile:
       if args.mode == "singularity":
           outfile.write(pbs_utils.get_pbs_settings(args.pbs_config, func_output_dir))
           outfile.write(f"singularity exec ${{IMAGE_DIR}} bash {feature_table_dir}/generate_func_feature_tables.sh\n")
       else:
           outfile.write(pbs_utils.get_pbs_header('func_table', 28, 12, 32, email, func_output_dir))
           outfile.write(f"bash generate_func_feature_tables.sh")



## TODO: move common function to utilities file
def get_base_filenames(input_dir, suffix):
    base_files = []
    search_path=f'{input_dir}*{suffix}'
    logging.debug(f"Searching in path [{search_path}]")
    for filename in glob.glob(f'{search_path}'):
        basename = os.path.basename(filename)
        if basename.find(suffix):
            prefix = re.sub(suffix, "", basename)
            base_files.append(prefix)
    return base_files




# %% Define parameters

parser = argparse.ArgumentParser(description='Function profiling module part of the MRC Metagenomics pipeline',
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
funcArgs = parser.add_argument_group("[2] Function profile settings")
pbsArgs = parser.add_argument_group("[3] PBS settings")
optionalArgs = parser.add_argument_group("[4] Optional arguments")


## Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                     required=True,
                     help='path to input directory of cleaned sequences (e.g. QC_module/CleanReads)')
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')
        
## Functional profiler
funcArgs.add_argument('--function-profiler',
                     choices=['humann3','humann2'],
                     default='humann3',
                     help="select profiler for function profiling [default=%(default)s]")
funcArgs.add_argument('--fwd-suffix',
                      default='_clean_1.fq.gz',
		      help='suffix of cleaned reads to search for in input_dir [default=%(default)s]')
funcArgs.add_argument('--rev-suffix',
                      default='_clean_2.fq.gz',
		      help='suffix of reverse cleaned reads for PBS script [default=%(default)s]')
funcArgs.add_argument('--nucleotide-database',
                      default='/refdb/humann/data/chocophlan',
                      help='HUMAnN3 directory containing the nucleotide database [default=%(default)s]')
funcArgs.add_argument('--protein-database',
                      default='/refdb/humann/data/uniref',
                      help='HUMAnN3 directory containing the protein database [default=%(default)s]')
funcArgs.add_argument('--utility-database',
                      default='/refdb/humann/data/utility_mapping',
                      help='HUMAnN3 utility mapping file [default=%(default)s]')
funcArgs.add_argument('--metaphlan-database',
                      default='/refdb/humann/metaphlan_databases',
                      help='Metaphlan3 reference database (CHOCOPhlAn) [default=%(default)s]')
funcArgs.add_argument('--mpa3', action='store_true', default=False, help='use Metaphlan 3 algorithm, used for backward compatibility with Metaphlan 3 databases')



# PBS settings
pbs_utils.add_pbs_parameters(requiredArgs, pbsArgs, default_mem=64, default_walltime=24, default_threads=28)

## Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this help message and exit')
## TODO: remove argument, using 'cat'
optionalArgs.add_argument('--pipeline-dir',
                    required=False,
                    type=str,
                    default=os.path.dirname(os.path.realpath(__file__)),
                    help='directory of pipeline script for finding combine_fastq.jl')
optionalArgs.add_argument('--verbose',
                    action='store_true',
                    default=False,
                    help="turn on to show verbose messages")
optionalArgs.add_argument('--debug',
                    action='store_true',
                    default=False,
                    help="turn on to show debugging messages")


# %% entry
if __name__ == '__main__':
    if len(argv)==1:
        parser.print_help()
        exit(0)
    args = parser.parse_args()

    # set up logger, TODO: split levels later
    logging.getLogger('').setLevel(logging.WARNING)
    if args.verbose:
        logging.getLogger('').setLevel(logging.INFO)

    if args.debug:
        logging.getLogger('').setLevel(logging.DEBUG)

    args_str = str(args).replace(',', '\n')
    logging.debug(f'--- ARGUMENTS ---\n{args_str}\n---')

   
    
    # %% Check directory paths, ensure ends with /
    input_dir = sanitise_directory_name(args.input_dir)
    if not os.path.isdir(input_dir):
        logging.error("Input directory does not exist: %s", input_dir)
        exit(3)
    
    output_dir = sanitise_directory_name(args.output_dir)
    output_dir += "Function_profiling/"
    
    pipeline_dir = sanitise_directory_name(args.pipeline_dir)

    if args.utility_database.endswith('/'):
        args.utility_database = args.utility_database[:-1]
    
    
    # %% Creates output directories
    logging.info("Setting up output directories ...")
    logging.debug(f"Create: {pipeline_dir}")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
     
    
    # %% Generate PBS scripts
    base_files = get_base_filenames(input_dir, args.fwd_suffix)
    logging.debug(f"Num files found [{len(base_files)}]")
    for basefile in base_files:
        if args.mode == 'singularity':
            headers = pbs_utils.get_pbs_settings(args.pbs_config, output_dir)
        else:
            headers = pbs_utils.get_pbs_header(f"{basefile}_func", 
                                 args.threads,
                                 args.walltime,
                                 args.mem,
                                 args.email,
                                 output_dir)
        
        ## TODO: don't put both into forloop
        PROFILERS={'humann2':get_humann2_command(input_dir,
                                                 basefile,
                                                 pipeline_dir,
                                                 args.threads),
                   'humann3':get_humann3_command(args.mode,
                                                 input_dir, 
                                                 basefile,
                                                 args.threads,
                                                 args.fwd_suffix,
                                                 args.rev_suffix,
                                                 output_dir,
                                                 args.nucleotide_database,
                                                 args.protein_database,
                                                 args.mpa3,
                                                 args.metaphlan_database)}
        
        pbsFile = f'{output_dir}{basefile}.pbs'
        logging.debug("Writing: %s", pbsFile)
        with open(pbsFile, "+w") as outfile:
            outfile.write(headers)
            outfile.write(PROFILERS[args.function_profiler])

    ## PBS script for generate feature table
    if args.function_profiler == 'humann3':
       logging.debug("Check profiler")
       generate_humann_feature_tables(output_dir, args.email, args)
