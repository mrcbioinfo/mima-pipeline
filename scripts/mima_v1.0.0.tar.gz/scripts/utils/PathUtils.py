"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Common functions for files and directory paths

"""

def sanitise_directory_name(dirname):
    """
    Checks dirname ends with '/', will append if not

    Parameters
    ----------
    dirname : string
        input directory name

    Returns
    -------
    dirname ending in '/'

    """
    if not dirname.endswith("/"):
        dirname += '/'
    return(dirname)