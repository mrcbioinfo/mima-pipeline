"""
Copyright (c) 2020-2022, USNW MRC Bioinformatics team.

Visualisation module

This is part of the MRC Metagenomics pipeline. This is the visualisation 
module that generates alpha-diversity and beta-diversity visualisations. Plots
are generated using R scripts.

The pipeline is suitable for metagenomic analyses where samples are processed by
shotgun sequencing using paired-end libraries.

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import logging
import os
import subprocess

from sys import argv

from models import TaxonomyProfile, MetadataFile


# %% Define parameters
parser = argparse.ArgumentParser(description='Visualisation module part of the MRC Metagenomics pipeline',
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
processArgs = parser.add_argument_group("[2] Processing arguments")
optionalArgs = parser.add_argument_group("[3] Optional arguments")


## required arguments
requiredArgs.add_argument('--feature-table',
                          required=True,
                          type=argparse.FileType('r', encoding='UTF-8'),
                          nargs='+',
                          help="""Path to the tab-separated feature table file 
where rows are Features and columns are Samples. The first column header should
be either:

<empty>|ID|# Pathway|# Gene|# IGGsearch species table

Other heading columns are current unsupported and no output will be generated.
""")
                    
requiredArgs.add_argument('--metadata',
                          required=True,
                          type=argparse.FileType('r', encoding='UTF-8'),
                          help='Path to the tab-/comma-separated metadata file')
                    
requiredArgs.add_argument('--study-groups',
                          required=True,
                          help='Comma separated list of column names in the metadata table which contain the study groups of interest')
                    
requiredArgs.add_argument('--output-dir',
                          required=True,
                          help='Output directory')


## processing arguments
processArgs.add_argument("--plot-insignificant", 
                         action='store_true',
                         default=False,
                         help='turn on to generate plots for insignificant comparisons')
processArgs.add_argument('--ini-file',
                          default='figures.ini',
                          help='Configuration file for figure parameters e.g., size [default: %(default)s]')


## optional arguments
optionalArgs.add_argument('-h','--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help='show this message and exit')
optionalArgs.add_argument("--verbose",
                          action='store_true',
                          default=False,
                          help="turn on verbose messages")
optionalArgs.add_argument("--debug",
                          action='store_true',
                          default=False,
                          help="turn on debugging messages")



# %% entry
if __name__ == '__main__':
    if len(argv) == 1:
        parser.print_help()
        exit(0)
    args = parser.parse_args()
    
    logging.getLogger('').setLevel(logging.WARNING)
    if (args.verbose):
        logging.getLogger('').setLevel(logging.INFO)

    if (args.debug):
        logging.getLogger('').setLevel(logging.DEBUG)

    logging.info("Running the visualisation module")
    args_str = str(args).replace(',', '\n')
    logging.debug(f"--- ARGUMENTS ---\n{args_str}\n---")

    ## get study groups
    study_groups = args.study_groups.split(',')
    feature_tables = args.feature_table
    
    ## FIXME: need more robust call to R script
    abs_path=os.path.dirname(os.path.realpath(__file__))
    r_script_path = f"{abs_path}/visualisation.R"
    ## FIXME: windows path backslash
    r_script_path = r_script_path.replace("\\","/")
    
    metadata_file = MetadataFile(args.metadata)
    metadata_file.drop_unneeded_fields(study_groups)

    for matrix in feature_tables:
        tax_profile = TaxonomyProfile.from_unknown_profile_file_format(matrix)
        tax_profile.enrich_matrix_with_metadata(metadata_file.df)
    
        # Create temporary working directory
        ## TODO: should not rely on the classification tool
        work_dir = os.path.abspath(f'{args.output_dir}/{tax_profile.classification_tool}')
        ## FIXME: windows path backslash
        work_dir = work_dir.replace("\\", "/")
        if not os.path.exists(work_dir):
            logging.debug(f"Create: {work_dir}")
            os.makedirs(work_dir)
    
        # Write data frame
        tax_profile_meta = f'{work_dir}/TaxProfileWithMeta.txt'
        tax_profile.df.to_csv(tax_profile_meta, sep='\t')
    
        ## TODO: add ini file to parameters
        try:
            commands = ['Rscript', r_script_path,
                        '--working-dir', work_dir,
                        '--feature-meta-table', tax_profile_meta,
                        '--num-meta-columns', str(len(study_groups))]
            
            if args.plot_insignificant:
               commands.append('--plot-insignificant')

            if args.debug:
               commands.append('--debug')

            output = subprocess.run(commands)
        except subprocess.CalledProcessError as e:
            logging.error(f"!!ERROR: {e.returncode}")
            logging.debug(f"--- RScript output ---\n{e.stdout}")

