# Visualisation Module

Install Dependencies;
```
cd scripts/visualisation
pip install -r requirements.txt
```

Example execution:
```
cd scripts/visualisation
python -m visualisation --data_matrix ../../test/Data_matrix_input/IGG/normalized_species_table.txt --metadata ../../test/meta_MUMS/meta_MUMS.txt --treatment_groups MUM,trimester --out_dir ../../test/
```