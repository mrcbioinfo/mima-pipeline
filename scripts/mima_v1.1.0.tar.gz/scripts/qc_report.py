"""
Quality Check module - QC reporting

This is part of the MRC Metagenomics pipeline. 

This script creates a QC report for the sequences in your study in the 
output_dir/QCmodule/qc_report.tsv. It depends on the JSON output files from
FastP and the PBS log files.

The script assumes that the PBS log files are in the same directory that
contains the QCReport directory created from qc_module.py

Documentation and Tutorials is located at [TODO: add URL]

"""

import argparse
import pandas as pd
import glob
import os
import re
import json
import logging

from sys import argv
from numpy import NAN

# %% Define parameters
parser = argparse.ArgumentParser(description="Generates QC report of your sequences",
                                 add_help=False,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
requiredArgs = parser.add_argument_group("[1] Required arguments")
optionalArgs = parser.add_argument_group("[2] Optional arguments")

## Required arguments
requiredArgs.add_argument('-i', '--input-dir',
                          required=True,
                          help="""path to directory which consists the QCReport 
folder from qc_module.py script. The QCReport folder contains the JSON report
from FastP. This script assumes that the PBS log files are in this directory. It will 
search for PBS log files with the suffix 'qc_module.oXXX' where XXX is the 
PBS job ID.""")
requiredArgs.add_argument('-o', '--output-dir',
                     required=True,
                     help='path to output directory')
requiredArgs.add_argument('-m', '--manifest',
                     required=True,
                     help="""path to manifest file in .csv format. The header line
is case sensitive, and must follow the following format with no spaces between commas.
Sample_ID,FileID_R1,FileID_R2
""")


# Optional settings
optionalArgs.add_argument('-h', '--help',
                          action='help',
                          default=argparse.SUPPRESS,
                          help = 'show this message and exit')
optionalArgs.add_argument('--verbose',
                          action='store_true', 
                          default=False,
                          help="turn on will return verbose message")
optionalArgs.add_argument('--debug',
                          action='store_true',
                          default=False,
                          help="turn on will return debugging messages")

# %% main entry
if __name__ == '__main__':
    if len(argv) == 1:
        parser.print_help()
        exit()
    args = parser.parse_args()
    
    # %% Parse input
    
    # TODO: Reuse common code with qc_module.py
    manifest = args.manifest
    df = pd.read_csv(manifest)
    file_manifest = df.to_dict('records')
    
    # set up logger, TODO: split levels later   
    if (args.verbose):
        logging.getLogger('').setLevel(logging.INFO)
    elif (args.debug):
        logging.getLogger('').setLevel(logging.DEBUG)
    else:
        logging.getLogger('').setLevel(logging.WARNING)
    
    logging.debug("Number of files: %d", len(file_manifest))
    
    # %% Check directory paths, ensure ends with /
    input_dir=args.input_dir
    #if input does not end with
    if not input_dir.endswith("/"):
        input_dir += '/'
    
    ##if output does not end with / add and a /
    output_dir = args.output_dir
    if not output_dir.endswith("/"):
       output_dir += '/'
    
    # output will be in 'QCmodule' directory
    output_dir += "QC_module/"    
    
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    
    #%% Generate QC report
    
    ## TODO: need to allow error checking of PBS log files - failed steps
    
    qcReport = qcReport = f'{output_dir}QC_report.csv'
    seq_info_list = []
    for ID in file_manifest:
        sampleID = ID["Sample_ID"]
        logging.debug("===\nParsing: %s", sampleID)
        
        seqinfo = { "id": sampleID }
        seq_info_list.append(seqinfo)
        pbs_log = [f for f in glob.glob(f"{input_dir}{sampleID}_qc_module.o*")]
        json_file=f'{input_dir}QCReport/{ID["Sample_ID"]}.json'
        if not(os.path.exists(json_file)):
            continue
        with open(pbs_log[0], 'r') as qc_log, open(json_file, 'r') as json_file:
            json_data = json.load(json_file)
            summary = (json_data["summary"])
            after_filter = (summary["after_filtering"])
            
            ## number of sequences remaining post QC
            seqinfo["post_qc"] = (after_filter["total_reads"])
            logging.debug(f"post_qc: {seqinfo['post_qc']}")
            ## find sequence log information in qc_log
            for line in qc_log:
                raw_reads = re.search('Reads In:\s+(\d+)', line)
                if raw_reads:
                    ## number of raw sequence reads
                    seqinfo["raw_reads"] = raw_reads.group(1)
                    logging.debug(f"raw_reads: {seqinfo['raw_reads']}")
                reads_out_match = re.search('Reads Out:\s+(\d+)', line)
                if reads_out_match:
                    if "dedup_seqs" not in seqinfo:
                        ## number of sequence reads after clumpify.sh
                        seqinfo["dedup_seqs"] = int(reads_out_match.group(1))
                        logging.debug(f"dedup_seqs: {seqinfo['dedup_seqs']}")
                    else:
                        ## number of sequence reads after host removal
                        seqinfo["clean_reads"] = int(reads_out_match.group(1))
                        logging.debug(f"clean_reads: {seqinfo['clean_reads']}")
                ## percentage duplicates identified
                dedup_precentage = re.search('Duplication rate:\s+(\d+.\d+)\%',line)
                if dedup_precentage:
                    ## percentage PCR duplicates removed
                    seqinfo["dedup_percentage"] = dedup_precentage.group(1)
                    logging.debug(f"dedup_percentage: {seqinfo['dedup_percentage']}")
    
    
            # XYC: workaround for failed steps and PBS logs with error messages
            if "raw_reads" not in seqinfo:
                seqinfo["raw_reads"] = NAN
                logging.warning("[%s] missing 'raw_reads' stats, dereplication QC step probably failed", sampleID)
                
            if "dedup_seqs" not in seqinfo:
                seqinfo["dedup_seqs"] = NAN
                logging.warning("[%s] missing 'dedup_seqs' stats, dereplication QC step probably failed", sampleID)

            if "dedup_percentage" not in seqinfo:
                seqinfo["dedup_percentage"] = NAN
                logging.warning("[%s] missing 'dedup_percentage' stats, dereplication QC step probably failed", sampleID)
    
            if "clean_reads" not in seqinfo:
                seqinfo["clean_reads"] = NAN
                logging.warning("[%s] missing 'clean_reads' stats, a QC step probably failed", sampleID)
    
            seqinfo["qc_removed"] = ((seqinfo["dedup_seqs"] - seqinfo["post_qc"]) / seqinfo["dedup_seqs"])*100 if seqinfo["dedup_seqs"] != 0 else NAN 
            seqinfo["host_seq"] = seqinfo["post_qc"] - seqinfo["clean_reads"]
            seqinfo["host_percent"] = ((seqinfo["post_qc"] - seqinfo["clean_reads"])/seqinfo["post_qc"])*100 if seqinfo["post_qc"] != 0 else NAN
    
            #print(seqinfo)
    
            with open(qcReport, "w+") as output_file:
                header = "SampleId,Rawreads_seqs,Derep_seqs,PCR_duplicates(%),Post_QC_seqs,low_quality_reads(%),Host_seqs,Host(%),Clean_reads\n"
                output_file.write(header)
                for seqinfo in seq_info_list:
                    sample_list = [
                        seqinfo["id"],
                        seqinfo["raw_reads"],
                        seqinfo["dedup_seqs"],
                        seqinfo["dedup_percentage"],
                        seqinfo["post_qc"],
                        seqinfo["qc_removed"],
                        seqinfo["host_seq"],
                        seqinfo["host_percent"],
                        seqinfo["clean_reads"]
                    ]
                    output_file.write(','.join(str(x) for x in sample_list))
                    output_file.write('\n')
    
    
    logging.info("Output: %s", qcReport)
