#!/bin/python3
#
# Helper functions for common PBS parameters and headers

import argparse
PBS_SETTINGS=""

def get_pbs_header(job_name, threads, walltime, mem, email, output_dir):
    """
    Function for PBS header template

    Parameters
    ----------
        job_name : str
            name for PBS job
        threads : int
            Number of threads for job
        walltime : int
            Number of hours predicted for job
        mem : int
            Memory (GB) required for job
        email : str
            User email address
        output_dir str: 
            Path to output where results will be saved

    Returns:
        str: PBS header settings
    """

    pbs_header = f"""#!/bin/bash
#PBS -N {job_name}
#PBS -l ncpus={threads}
#PBS -l walltime={walltime}:00:00
#PBS -l mem={mem}GB
#PBS -m ae
#PBS -j oe
#PBS -M {email}

cd {output_dir}

conda activate mima
"""
    return pbs_header


def get_pbs_settings(config_file, output_dir):
    """
    Function for PBS header from a configuration file

    Parameters
    ----------
        config_file : str
	    path to PBS configuration file, contents will be included at the top of all PBS scripts
    """

    global PBS_SETTINGS
    if not PBS_SETTINGS:
        PBS_SETTINGS = config_file.readlines()
        PBS_SETTINGS = "".join(PBS_SETTINGS) + f"\ncd {output_dir}\n\n"

    return PBS_SETTINGS



def add_pbs_parameters(requiredArgs, pbsArgs, default_mem, default_walltime, default_threads):
    """
    Function for adding the common PBS parameters to tool menu.
    """
    
    # PBS settings
    pbsArgs.add_argument('--mode',
                        required=False,
                        choices=['single','singularity'],
                        type=str,
                        default='single',
                        help='Mode to generate PBS scripts, currently supports single sample mode only [default=%(default)s]')
    pbsArgs.add_argument('-w', '--walltime',
                        required=False,
                        type=int,
                        default=default_walltime,
                        help='walltime hours required for PBS job of MODE [default=%(default)s]')
    pbsArgs.add_argument('-M', '--mem',
                        required=False,
                        type=int,
                        default=default_mem,
                        help='memory (GB) required for PBS job of MODE [default=%(default)s]')
    pbsArgs.add_argument('-t', '--threads',
                        type=int,
                        default=default_threads,
                        help='number of threads for PBS job of MODE [default=%(default)s]')
    pbsArgs.add_argument('-e', '--email',
                        type=str,
                        help='PBS setting - email address')
    pbsArgs.add_argument('--pbs-config',
                        type=argparse.FileType('r'),
			help='Must be set when --mode singularity. Path to PBS configuration file which must includ PBS headers and any other required settings to run the singularity image. Contents in the config file will be included at the top of all generated PBS scripts [default=%(default)s]')
