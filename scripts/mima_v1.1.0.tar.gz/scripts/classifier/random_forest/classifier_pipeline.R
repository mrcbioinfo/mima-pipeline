#!/srv/scratch/z3527776/tool/R-3.6.0/bin/Rscript

#######
###	load packages and dependent functions
#######
library(optparse)
library(caret)
library(mlr)
library(kernlab)
library(randomForest)
library(ranger)
library(pROC)
library(ggplot2)
library(RColorBrewer)
library(reshape2)
library(foreach)
library(doParallel)

#######
###	parse parameters
#######
option_list = list(
    make_option(c("-i", "--input"), 
                type = "character",
                default = NULL, 
                help = "input file: a list of tab seperated feature tables 
                with rows (first row is header) and columns (first column is 
                sample ID) indicate features and samples, respectively"),
    make_option(c("-m", "--metadata"), 
                type = "character", 
                default = NULL, 
                help = "input file of study metadata where the first row is 
                header and the first column is assumed to be the same ID. The 
                metadata is applied to all the feature tables"),
    make_option(c("-c", "--column"),
                type = 'character',
                default = NULL,
                help = 'column header from the metadata table that contains 
                the grouping categories for classfication'),
    make_option(c("-o", "--output"), 
                type = "character", 
                default = NULL, 
                help = "output directory")
)
opt_parser = OptionParser(option_list = option_list)
opt = parse_args(opt_parser)

my_inputTable = as.list(strsplit(opt$input, ",")[[1]])
my_metadata = opt$metadata
my_column = opt$column
my_outputPath = opt$output


if (!dir.exists(my_outputPath)) {
  dir.create(my_outputPath)
}


#######
###	functions
#######
mY_input = function(my_inputTable, metadata){
    fun_in = my_inputTable
    fun_meta = metadata
    fun_combined = c()
    fun_out = list()
    for(i_file in 1 : length(fun_in)){
        mat = read.table(fun_in[[i_file]], header = T, sep = '\t')
        rownames(mat) = mat[,1]
        print(dim(mat))
        mat_raw = mat[, 2 : dim(mat)[2]]
        mat_keep = rowSums(mat_raw == 0) < dim(mat_raw)[2]
        mat_exp = mat_raw[mat_keep,]
        mat_exp = t(mat_exp)
        print(dim(mat_exp))
        fun_combined = cbind(fun_combined, mat_exp)
        mat_feature = mY_featureName(mat_exp, fun_meta)
        fun_out[[paste("data", i_file, sep = "_")]] = mat_feature
        print(paste("data", i_file, sep = "_"))
    }
    if(length(fun_in) > 1){
        mat_feature_combined = mY_featureName(fun_combined, fun_meta)
        fun_out[["data_all"]] = mat_feature_combined
        print("data_all")
    }
    return(fun_out)
}

mY_featureName = function(mat_exp, fun_meta){
    fun_in = mat_exp
    fun_meta = fun_meta
    feature_name = data.frame(feature = colnames(fun_in), temp_f = sapply(1 : dim(fun_in)[2], function(x){paste0("f_", x)}))
    colnames(fun_in) = feature_name$temp_f
    fun_out = cbind(fun_in, fun_meta)
    fun_out = subset(fun_out, select = -c(SampleID))
    attr(fun_out, "feature_name") = feature_name
    return(fun_out)
}

mY_classification = function(list_in){
    fun_in = list_in
    i_in = names(fun_in)
    names(i_in) = names(fun_in)
    fun_out = lapply(i_in, function(x){
        mat_name = x
        mat = fun_in[[x]]
        print(mat_name)
        feature_name = attributes(mat)
        feature_name = feature_name$feature_name
        mY_cv(mat, feature_name, mat_name)
    })
    return(fun_out)
}

mY_cv = function(mat, feature_name, mat_name){
    fun_in = mat
    fun_feature_name = feature_name
    fun_mat_name = mat_name
    fun_out = list()
###	machine learning methods to be used and the output feature importances names
    #vector_mlr = c("classif.randomForest", "classif.ksvm", "classif.logreg")
    #vector_mlr = c("classif.ranger", "classif.ksvm", "classif.logreg")
    vector_mlr = c("classif.randomForest")
    vector_coef = c("variable.importance", "null", "coefficients")
###	fold number from 3 to 10
    vector_cv = c(3 : 10)
    vector_package = c("caret", "mlr", "kernlab", "ranger", "randomForest", "pROC", "ggplot2", "RColorBrewer")
### create a parallel socket cluster and not overload your computer
    num_core = 8
    #num_core = detectCores()
    print(paste0("Number of cores: ", num_core))
    socket_cluster = makeCluster(num_core[1] - 2, outfile = "socket_cluster_log.txt")
    print(socket_cluster)
    registerDoParallel(socket_cluster)
###	parallelly for all the number of folds
    #start_time = Sys.time()
    fun_out = foreach(i_mlr=vector_mlr,i_coef=vector_coef, .packages=vector_package) %:%
        foreach(i_fold = vector_cv, .export = 'mY_ml_roc') %dopar% {
            mlr_out = mY_ml_roc(fun_in, i_fold, i_mlr, i_coef)
        }
###	name the first level of the fun_out as machine learning methods
    names(fun_out) = vector_mlr
###	name the second level of the fun_out as cross validation folds
    for(i_m in vector_mlr){
        temp_m = fun_out[[i_m]]
        print(i_m)
###	the folds of cross validation
        cv_name = sapply(temp_m, function(x){
            attr = attributes(x)
            attr$cv
        })
        print(cv_name)
        names(fun_out[[i_m]]) = cv_name
###	the feature importance
        feature_importance = sapply(temp_m, function(x){
            attr = attributes(x)
            attr$importance
        })
###	consider only the machine learning methods that output feature importance
        if(!is.null(feature_importance[[1]])){
            colnames(feature_importance) = cv_name
###	remove the importance that are not from features, e.g., "Intercept"
            feature_importance = feature_importance[rownames(feature_importance) %in% fun_feature_name$temp_f,]
            feature_importance = cbind(feature_importance, fun_feature_name)
###	for each machine learning method, output a file
            write.table(feature_importance, file = paste("feature_importance_", fun_mat_name, "_", i_m, ".txt", sep = ''), row.names = T, quote = F, sep = "\t")
        }
    }
    #end_time = Sys.time()
    #print(end_time - start_time)
###	stop cluster
    stopCluster(socket_cluster)
    #print("The cluster is stopped!")
###	return
    return(fun_out)
}

mY_ml_roc = function(mat, i_fold, i_mlr, i_coef){
    fun_in = mat
    fun_fold = i_fold
    fun_mlr = i_mlr
    fun_coef = i_coef
###	Set Seed so that same sample can be reproduced in future
    set.seed(101)
    folds = createFolds(rownames(fun_in), k = fun_fold, list = FALSE)
    fun_out = c()
    fun_out_coef = c()
    for(i_f in 1 : fun_fold){
###	Training and testing
        #print(fun_fold)
        #print(i_f)
        training = seq_len(nrow(fun_in))[folds != i_f]
        testing = seq_len(nrow(fun_in))[folds == i_f]
        #print(length(testing))
###	call mlr package
        task = makeClassifTask(data = fun_in, target = "Category")
###	get parameter list
        #getParamSet(fun_mlr)
        if(fun_mlr == "classif.ranger"){
            learner = makeLearner(fun_mlr, predict.type = "prob", num.threads = 16, importance = "impurity")
        }else{
            learner = makeLearner(fun_mlr, predict.type = "prob")
        }
        fit = mlr::train(learner, task, subset = training)
        #print(fit)
        pred = predict(fit, task, subset = testing)
        fun_out = rbind(fun_out, pred$data)
        #tryCatch({fun_out_coef = cbind(fun_out_coef, fit$learner.model[[fun_coef]])}, error = function(e){print(fun_mlr)})
        if(fun_coef != "null"){
            fun_out_coef = cbind(fun_out_coef, fit$learner.model[[fun_coef]])
        }
    }
### output the feature importance as an attribute
    #tryCatch({attr(fun_out, "importance") = rowMeans(fun_out_coef)}, error = function(e){print(fun_mlr)})
    if(!is.null(fun_out_coef)){
        attr(fun_out, "importance") = rowMeans(fun_out_coef)
    }
### output the folds of cross validation as an attribute
    attr(fun_out, "cv") = paste0("cv_", i_fold)
###	ROC
    roc = roc(fun_out$truth, fun_out[,3], ci = T)
    roc_ci = roc$ci
    roc_ci = paste0("95% CI: ", round(roc_ci[1], 3), "-", round(roc_ci[3], 3))
    auc = round(roc$auc, 3)
###	confidence interval
    roc_bootstrap = ci.se(roc, specificities = seq(0, 1, l = 50), boot.n = 1000)
    ci_bootstrap = data.frame(x = as.numeric(rownames(roc_bootstrap)), lower = roc_bootstrap[, 1], upper = roc_bootstrap[, 3])
    fun_roc = list(roc = roc, roc_ci = roc_ci, auc = auc, ci_bootstrap = ci_bootstrap)
    attr(fun_out, "roc") = fun_roc
###	return
    return(fun_out)
}

mY_plot = function(list_out){
    fun_in = list_out
    mat_name = names(fun_in)
    classifier_name = names(fun_in[[1]])
    fold_name = names(fun_in[[1]][[1]])
###	first, for each dataset, plot auc against number of fold
    list_auc_cv = lapply(mat_name, function(x){
        print(x)
        temp_mat = fun_in[[x]]
        table_mat = sapply(classifier_name, function(y){
            print(y)
            temp_classifier = temp_mat[[y]]
            sapply(fold_name, function(z){
                temp_fold = attributes(temp_classifier[[z]])
                print(temp_fold$roc$auc)
            })
        })
        plot_auc = melt(table_mat)
        colnames(plot_auc) = c("cv", "variable", "value")
        p_a = ggplot(plot_auc, aes(x = cv, y = value, group = variable,
                                   colour = variable)) +
        geom_point() +
        geom_line(aes(lty = variable)) +
        xlab("No. of folds") +
        ylab("AUC") +
        ylim(0.5, 1) +
        ggtitle(x) + 
        theme_bw() + 
        theme(panel.grid=element_blank(),
              axis.text.x = element_text(size = 18),
              axis.text.y = element_text(size = 18),
              axis.title.x = element_text(size = 18),
              axis.title.y = element_text(size = 18))
        return(p_a)
    })
    names(list_auc_cv) = mat_name
###	plot
    pdf("cv_auc.pdf", width = 9, height = 7, onefile = T)
    lapply(mat_name, function(x){
        print(list_auc_cv[[x]])
    })
    dev.off()
###	plot roc with confidence interval
    list_auc_ci = lapply(mat_name, function(x){
        print(x)
        temp_mat = fun_in[[x]]
        table_mat = lapply(classifier_name, function(y){
            print(y)
            temp_classifier = temp_mat[[y]]
            lapply(fold_name, function(z){
                temp_fold = attributes(temp_classifier[[z]])
                pr = ggroc(temp_fold$roc$roc, color = "purple") +
                geom_abline(slope = 1, intercept = 1, linetype = "dashed", alpha = 0.7,
                            color = "black") +
                coord_equal() +
                geom_ribbon(data = temp_fold$roc$ci_bootstrap, fill = "purple",
                            aes(x = x, ymin = lower, ymax = upper), alpha= 0.1) +
                ggtitle(paste(x, y, z, paste0("AUC: ", temp_fold$roc$auc, " (",
                              temp_fold$roc$roc_ci, ")"), sep = ', ')) +
                theme_bw() +
                theme(panel.grid = element_blank(),
                      axis.text.x = element_text(size = 18),
                      axis.text.y = element_text(size = 18),
                      axis.title.x = element_text(size = 18),
                      axis.title.y = element_text(size = 18))
                return(pr)
            })
        })
    })
    names(list_auc_ci) = mat_name
###	plot
    lapply(mat_name, function(x){
        temp_mat = list_auc_ci[[x]]
        pdf(paste("roc_", x, ".pdf", sep = ''), width = 9, height = 7, onefile = T)
        sapply(1 : length(classifier_name), function(y){
            sapply(1 : length(fold_name), function(z){
                print(temp_mat[[y]][[z]])
            })
        })
        dev.off()
    })
###	for each dataset, plot roc with combined classifier
    list_auc_cf = lapply(mat_name, function(x){
        print(x)
        temp_mat = fun_in[[x]]
        table_mat = lapply(fold_name, function(z){
            print(z)
            list_cv = lapply(classifier_name, function(y){
                temp_fold = attributes(temp_mat[[y]][[z]])
                temp_fold$roc$roc
            })
            list_cv_auc = sapply(classifier_name, function(y){
                temp_fold = attributes(temp_mat[[y]][[z]])
                temp_fold$roc$auc
            })
            names(list_cv) = paste(classifier_name, list_cv_auc)
            pr = ggroc(list_cv) +
            geom_abline(slope = 1, intercept = 1, linetype = "dashed", alpha = 0.7,
                        color = "black") +
            coord_equal() +
            ggtitle(paste(x, z, sep = ', ')) +
            theme_bw() +
            theme(panel.grid = element_blank(),
                  axis.text.x = element_text(size = 18),
                  axis.text.y = element_text(size = 18),
                  axis.title.x = element_text(size = 18),
                  axis.title.y = element_text(size = 18))
            return(pr)
        })
    })
    names(list_auc_cf) = mat_name
###	plot
    lapply(mat_name, function(x){
        temp_mat = list_auc_cf[[x]]
        pdf(paste0("roc_", x, "_classifier.pdf"), width = 9, height = 7, onefile = T)
        sapply(1 : length(fold_name), function(z){
            print(temp_mat[[z]])
        })
        dev.off()
    })
###	for each classifier, plot roc with combined data
    list_auc_data = lapply(classifier_name, function(y){
        print(y)
        table_mat = lapply(fold_name, function(z){
            print(z)
            list_cv = lapply(mat_name, function(x){
                print(x)
                temp_fold = attributes(fun_in[[x]][[y]][[z]])
                temp_fold$roc$roc
            })
            list_cv_auc = sapply(mat_name, function(x){
                temp_fold = attributes(fun_in[[x]][[y]][[z]])
                temp_fold$roc$auc
            })
            names(list_cv) = paste(mat_name, list_cv_auc)
            pr = ggroc(list_cv) +
            geom_abline(slope = 1, intercept = 1, linetype = "dashed", alpha = 0.7,
                        color = "black") +
            coord_equal() +
            ggtitle(paste(y, z, sep = ', ')) +
            theme_bw() +
            theme(panel.grid = element_blank(),
                  axis.text.x = element_text(size = 18),
                  axis.text.y = element_text(size = 18),
                  axis.title.x = element_text(size = 18),
                  axis.title.y = element_text(size = 18))
            return(pr)
        })
    })
    names(list_auc_data) = classifier_name
###	plot
    lapply(classifier_name, function(y){
        temp_mat = list_auc_data[[y]]
        pdf(paste0("roc_", y, "_dataset.pdf"), width = 9, height = 7, onefile = T)
        sapply(1 : length(fold_name), function(z){
            print(temp_mat[[z]])
        })
        dev.off()
    })
}

#######
###	main
#######
if(!is.null(my_inputTable) && !is.null(my_metadata) && !is.null(my_outputPath)){
###	if the input data files are applied
###	metadata
    full.metadata = read.table(my_metadata, header = T, sep='\t')
    ix <- grep(my_column, names(full.metadata))
    metadata <- full.metadata[,c(1,ix)]
    rownames(metadata) = metadata[,1]
    colnames(metadata) = c("SampleID", "Category")
###	list of input files and the combined input
    list_in = mY_input(my_inputTable, metadata)
###	classification
    setwd(my_outputPath)
    start_time = Sys.time()
    closeAllConnections()
    list_out = mY_classification(list_in)
###	plot
    mY_plot(list_out)
	  closeAllConnections()
    end_time = Sys.time()
}else{
###	manage null arguments
    print("All the parameters must be supplied!!!")
    print_help(opt_parser)
    stop("All the parameters must be supplied!!!", call.=FALSE)
}

